package com.kairnos.gearreroll;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.*;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.content.Context;
import android.graphics.PixelFormat;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import java.util.*;
import java.util.concurrent.Executor;

/**
 * Accessibility screenshot + on-device Chinese OCR + guarded gesture automation.
 * It never guesses when a level, set, rarity or stat row cannot be identified.
 */
public class GearAutomationService extends AccessibilityService {
    private static final String PREF="gear_settings";
    private static final String[] ANCHOR_NAMES={"套装/品质文字","等级文字","主词条文字","副词条列表"};
    private final Handler handler=new Handler(Looper.getMainLooper());
    private TextRecognizer recognizer;
    private WindowManager wm;
    private View floating;
    private View calibrationLayer;
    private WindowManager.LayoutParams floatingParams;
    private float dragStartRawX,dragStartRawY;
    private int dragStartX,dragStartY;
    private boolean busy=false;
    private boolean testOnly=false;
    private String foregroundPackage="";
    private int inventoryCursor=0;
    private long lastActionAt=0;
    private int calibrationIndex=0;
    private float screenW=1f,screenH=1f;
    private boolean awaitingInventory=false;
    private String lastVerifiedSet="", lastVerifiedRarity="", lastVerifiedPart="";
    private int lastVerifiedLevel=-1;

    private final Runnable loop=new Runnable(){@Override public void run(){
        if(enabled()&&!prefs().getBoolean("inventory_safe_confirmed",false))pauseAutomation("安全确认未完成，自动模式已锁定");
        if(enabled()&&!calibrationComplete())pauseAutomation("尚未完成四点识别校准，自动模式已锁定");
        if(enabled()&&!busy&&isTargetForeground())captureAndRead(false);
        handler.postDelayed(this,1400L);
    }};

    @Override public void onServiceConnected(){
        super.onServiceConnected();
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        recognizer=TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        refreshScreenSize();createFloatingBar();
        handler.removeCallbacks(loop);handler.post(loop);
        status("无障碍已连接；悬浮控制条已就绪");
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){
        if(event==null)return;
        if(event.getPackageName()!=null){foregroundPackage=event.getPackageName().toString();}
        if(enabled()){handler.removeCallbacks(loop);handler.postDelayed(loop,250L);}
    }
    @Override public void onInterrupt(){pauseAutomation("系统中断无障碍服务");}
    @Override public void onDestroy(){
        handler.removeCallbacksAndMessages(null);removeCalibrationLayer();removeFloatingBar();
        if(recognizer!=null)recognizer.close();super.onDestroy();
    }
    private SharedPreferences prefs(){return getSharedPreferences(PREF,MODE_PRIVATE);}
    private boolean enabled(){return prefs().getBoolean("auto_enabled",false);}
    private String target(){return prefs().getString("target_package","com.mobirate.DeadAheadTactics");}
    private String selectedSet(){return prefs().getString("gear_set","幸运儿");}
    private String selectedPart(){return prefs().getString("gear_part","全部");}
    private void refreshScreenSize(){
        try{android.util.DisplayMetrics m=new android.util.DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(m);screenW=m.widthPixels;screenH=m.heightPixels;}
        catch(Throwable ignored){screenW=getResources().getDisplayMetrics().widthPixels;screenH=getResources().getDisplayMetrics().heightPixels;}
    }
    private boolean isTargetForeground(){
        AccessibilityNodeInfo root=null;
        try{root=getRootInActiveWindow();String pkg=root!=null&&root.getPackageName()!=null?root.getPackageName().toString():foregroundPackage;return target().equals(pkg);}
        catch(Throwable ignored){return target().equals(foregroundPackage);}
        finally{if(root!=null)root.recycle();}
    }

    // ---------- Floating control strip ----------
    private void createFloatingBar(){
        if(wm==null||floating!=null)return;
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(9),dp(8),dp(9),dp(8));panel.setAlpha(0f);panel.setTranslationY(-dp(8));
        GradientDrawable bg=new GradientDrawable();bg.setColor(0xe9222b36);bg.setCornerRadius(dp(16));bg.setStroke(dp(1),0x99ffffff);panel.setBackground(bg);panel.setElevation(dp(10));
        TextView heading=new TextView(this);heading.setText("GEAR  ·  自动筛选  ·  按住拖动");heading.setTextColor(Color.WHITE);heading.setTextSize(10);heading.setTypeface(null,android.graphics.Typeface.BOLD);heading.setGravity(Gravity.CENTER);panel.addView(heading);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);panel.addView(row);
        addFloatButton(row,"开始",()->{if(!prefs().getBoolean("inventory_safe_confirmed",false)){status("请先在主界面确认库存安全条件");return;}if(!calibrationComplete()){status("请先完成四点识别校准");return;}prefs().edit().putBoolean("auto_enabled",true).putString("status","悬浮窗启动：等待目标游戏").apply();status("自动筛选已启动");});
        addFloatButton(row,"暂停",()->pauseAutomation("已暂停"));
        addFloatButton(row,"停止",()->{pauseAutomation("已紧急停止");inventoryCursor=0;awaitingInventory=false;});
        addFloatButton(row,"校准",this::beginCalibration);
        addFloatButton(row,"测试",()->captureAndRead(true));
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(dp(330),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL;lp.y=dp(72);floatingParams=lp;
        heading.setOnTouchListener((v,event)->{
            if(event.getAction()==MotionEvent.ACTION_DOWN){
                dragStartRawX=event.getRawX();dragStartRawY=event.getRawY();
                dragStartX=(int)((screenW-dp(330))/2f)+floatingParams.x;dragStartY=floatingParams.y;
                return true;
            }
            if(event.getAction()==MotionEvent.ACTION_MOVE){
                floatingParams.gravity=Gravity.TOP|Gravity.START;
                floatingParams.x=Math.max(0,Math.min((int)screenW-dp(330),dragStartX+(int)(event.getRawX()-dragStartRawX)));
                floatingParams.y=Math.max(0,Math.min((int)screenH-dp(72),dragStartY+(int)(event.getRawY()-dragStartRawY)));
                try{wm.updateViewLayout(panel,floatingParams);}catch(Throwable ignored){}return true;
            }
            return event.getAction()==MotionEvent.ACTION_UP||event.getAction()==MotionEvent.ACTION_CANCEL;
        });
        try{wm.addView(panel,lp);floating=panel;panel.animate().alpha(1f).translationY(0f).setDuration(260).start();}catch(Throwable e){status("悬浮控制条创建失败："+e.getClass().getSimpleName());}
    }
    private void addFloatButton(LinearLayout parent,String text,Runnable action){
        TextView b=new TextView(this);b.setText(text);b.setTextColor(Color.WHITE);b.setTextSize(11);b.setGravity(Gravity.CENTER);b.setPadding(dp(9),dp(9),dp(9),dp(9));
        GradientDrawable d=new GradientDrawable();d.setColor(0xff455363);d.setCornerRadius(dp(10));b.setBackground(d);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(38),1);p.setMargins(dp(2),dp(6),dp(2),0);parent.addView(b,p);
        b.setOnClickListener(v->{v.animate().scaleX(.92f).scaleY(.92f).setDuration(75).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()).start();action.run();});
    }
    private void removeFloatingBar(){if(wm!=null&&floating!=null)try{wm.removeView(floating);}catch(Throwable ignored){}floating=null;floatingParams=null;}

    // ---------- Four OCR-region anchors on the currently open equipment detail page. ----------
    private void beginCalibration(){
        if(!isTargetForeground()){status("请先打开游戏，并进入一件装备的详情页，再启动校准");return;}
        if(calibrationLayer!=null)return;
        refreshScreenSize();calibrationIndex=0;
        FrameLayout layer=new FrameLayout(this);layer.setBackgroundColor(0x330b1320);layer.setClickable(true);
        TextView prompt=new TextView(this);prompt.setText(calibrationPrompt());prompt.setTextColor(Color.WHITE);prompt.setTextSize(16);prompt.setTypeface(null,android.graphics.Typeface.BOLD);prompt.setGravity(Gravity.CENTER);prompt.setPadding(dp(28),dp(24),dp(28),dp(24));
        GradientDrawable card=new GradientDrawable();card.setColor(0xe8202935);card.setCornerRadius(dp(20));card.setStroke(dp(1),0x99ffffff);prompt.setBackground(card);
        FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(-1,dp(134),Gravity.CENTER);pp.setMargins(dp(25),0,dp(25),0);layer.addView(prompt,pp);
        layer.setOnTouchListener((v,event)->{
            if(event.getAction()==MotionEvent.ACTION_UP){float x=event.getRawX(),y=event.getRawY();storeAnchor(calibrationIndex,x,y);calibrationIndex++;
                if(calibrationIndex>=4){removeCalibrationLayer();status("四点识别校准完成。不会触碰游戏按钮；请点“测试”核对识别结果");}
                else {prompt.setText(calibrationPrompt());status("已记录识别区域"+calibrationIndex+"/4："+ANCHOR_NAMES[calibrationIndex-1]);}
            }
            return true;
        });
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);
        try{wm.addView(layer,lp);calibrationLayer=layer;status("校准开始："+calibrationPrompt());}
        catch(Throwable e){calibrationLayer=null;status("无法显示校准层："+e.getClass().getSimpleName());}
    }
    private String calibrationPrompt(){
        String instruction;
        switch(calibrationIndex){case 0:instruction="① 点装备详情页中套装名称/品质文字所在区域";break;
            case 1:instruction="② 点装备等级数字所在区域（必须能看到等级1）";break;
            case 2:instruction="③ 点主词条名称与数值所在区域";break;
            default:instruction="④ 点副词条列表区域的中间位置";break;}
        return instruction+"\n请在同一装备详情页完成四次点选。触点只用于标记识别区域，不会传递给游戏，不会消耗重掷令牌。";
    }
    private void storeAnchor(int index,float x,float y){prefs().edit().putFloat("anchor_x_"+index,x/Math.max(1f,screenW)).putFloat("anchor_y_"+index,y/Math.max(1f,screenH)).putBoolean("anchor_valid_"+index,true).apply();}
    private void removeCalibrationLayer(){if(wm!=null&&calibrationLayer!=null)try{wm.removeView(calibrationLayer);}catch(Throwable ignored){}calibrationLayer=null;}
    private boolean hasAnchor(int index){return prefs().getBoolean("anchor_valid_"+index,false);}
    private boolean calibrationComplete(){return hasAnchor(0)&&hasAnchor(1)&&hasAnchor(2)&&hasAnchor(3);}
    private Point anchor(int index,Bitmap image){if(!hasAnchor(index))return null;float x=prefs().getFloat("anchor_x_"+index,.5f),y=prefs().getFloat("anchor_y_"+index,.5f);return new Point(Math.max(0,Math.min(image.getWidth()-1,(int)(x*image.getWidth()))),Math.max(0,Math.min(image.getHeight()-1,(int)(y*image.getHeight()))));}

    // ---------- Screenshot and offline OCR ----------
    private void captureAndRead(boolean onlyTest){
        if(Build.VERSION.SDK_INT<30){pauseAutomation("需要 Android 11 或更高版本的无障碍截屏接口");return;}
        if(busy)return;busy=true;testOnly=onlyTest;
        try{takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
            @Override public void onSuccess(ScreenshotResult result){
                Bitmap bitmap=null;HardwareBuffer hb=result.getHardwareBuffer();
                try{Bitmap wrapped=Bitmap.wrapHardwareBuffer(hb,result.getColorSpace());if(wrapped!=null)bitmap=wrapped.copy(Bitmap.Config.ARGB_8888,false);}
                catch(Throwable ignored){}finally{if(hb!=null)hb.close();}
                if(bitmap==null){busy=false;pauseAutomation("截图解码失败");return;}
                final Bitmap shot=bitmap;
                recognizer.process(InputImage.fromBitmap(shot,0))
                    .addOnSuccessListener(getMainExecutor(),text->{try{handleFrame(text,shot,onlyTest);}catch(Throwable e){pauseAutomation("识别流程异常："+e.getClass().getSimpleName());}})
                    .addOnFailureListener(getMainExecutor(),e->{if(!onlyTest)pauseAutomation("离线OCR识别失败："+e.getClass().getSimpleName());else status("OCR测试失败："+e.getClass().getSimpleName());})
                    .addOnCompleteListener(getMainExecutor(),task->{shot.recycle();busy=false;});
            }
            @Override public void onFailure(int errorCode){busy=false;if(!onlyTest)pauseAutomation("系统截图失败，错误码"+errorCode);else status("测试截图失败："+errorCode);}
        });}catch(Throwable e){busy=false;pauseAutomation("截图接口异常："+e.getClass().getSimpleName());}
    }
    private void handleFrame(Text text,Bitmap image,boolean onlyTest){
        if(!isTargetForeground()){if(onlyTest)status("测试停止：目标游戏不在前台");return;}
        GearOcrParser.Parsed parsed=GearOcrParser.parse(text,selectedSet(),selectedPart());
        GearRuleEngine.Snapshot s=parsed.snapshot;
        if(isResultScreen(parsed))hydrateResultMetadata(s);
        if(!isInventoryScreen(parsed) && s.level==1 && !s.set.isEmpty() && !s.rarity.isEmpty() && !s.part.isEmpty())rememberItemIdentity(s);
        if(onlyTest){
            String summary="识别测试：\n套装="+(s.set.isEmpty()?"未识别":s.set)+"  品质="+(s.rarity.isEmpty()?"未识别":s.rarity)+"\n等级="+s.level+"  部位="+s.part+"\n主词条="+(s.main.isEmpty()?"未识别":s.main)+"\n副词条="+String.join("、",s.subs)+"\n按钮="+buttonSummary(parsed)+"\n"+(s.uncertain?"状态：信息不足，自动模式会暂停":"状态：基础信息完整（仍建议人工核对）");
            status(summary+"\n四点校准："+(calibrationComplete()? (validateCalibration(parsed,image)?"通过":"锚点与当前详情页不匹配") : "未完成"));return;
        }
        if(!enabled())return;
        if(parsed.fullText.trim().isEmpty()){status("等待可识别的游戏界面文字");return;}
        if(isConfirmation(parsed)){
            Rect confirm=findButton(parsed,"重掷","确认","确定");
            if(confirm!=null){tapRect(confirm);status("已识别重掷确认按钮");return;}
            pauseAutomation("确认框出现，但无法通过OCR可靠定位重掷按钮");return;
        }
        if(isResultScreen(parsed)){
            GearRuleEngine.Result result=evaluate(s);
            if(result.decision==GearRuleEngine.Decision.UNKNOWN){pauseAutomation("结果页信息不完整，停止保护装备："+result.reason);return;}
            if(result.decision==GearRuleEngine.Decision.SKIP){pauseAutomation("结果页触发安全跳过："+result.reason);return;}
            if(result.decision==GearRuleEngine.Decision.KEEP){
                Rect back=findButton(parsed,"返回","关闭");
                if(back!=null){inventoryCursor++;awaitingInventory=true;tapRect(back);status("保留："+result.reason+"。返回库存后处理下一件");return;}
                pauseAutomation("命中保留条件，但找不到可确认的返回按钮");return;
            }
            Rect more=findButton(parsed,"继续");
            if(more!=null){tapRect(more);status("未命中："+result.reason+"，继续重掷同一件");return;}
            pauseAutomation("未命中词条，但无法通过OCR定位继续按钮");return;
        }
        if(isInventoryScreen(parsed)){
            lastVerifiedSet="";lastVerifiedRarity="";lastVerifiedPart="";lastVerifiedLevel=-1;
            selectNextInventory(parsed,image);return;
        }
        // Only a fully identified details screen can reach the reroll icon detector.
        if(s.set.isEmpty()){pauseAutomation("无法识别当前装备套装名，已暂停保护装备");return;}
        if(!s.set.equals(selectedSet())){
            Rect back=findButton(parsed,"返回","关闭");
            if(back!=null){inventoryCursor++;tapRect(back);status("当前是"+s.set+"，目标为"+selectedSet()+"，跳过");}
            else pauseAutomation("当前套装不是目标套装，但无法可靠定位返回按钮，已暂停");
            return;
        }
        if(!validateCalibration(parsed,image)){pauseAutomation("四点锚点与当前装备详情页文字不匹配；识别流程已暂停");return;}
        GearRuleEngine.Result result=evaluate(s);
        if(result.decision==GearRuleEngine.Decision.UNKNOWN){pauseAutomation("识别未完整，自动流程已暂停："+result.reason);return;}
        if(result.decision==GearRuleEngine.Decision.SKIP){
            Rect back=findButton(parsed,"返回","关闭");
            if(back!=null){inventoryCursor++;tapRect(back);status("安全跳过："+result.reason+"，返回库存继续检查");}
            else status("安全跳过："+result.reason+"；找不到返回按钮，保持静止");
            return;
        }
        if(result.decision==GearRuleEngine.Decision.KEEP){
            Rect back=findButton(parsed,"返回","关闭");if(back!=null){inventoryCursor++;tapRect(back);status("当前装备达标："+result.reason+"，换下一件");}else status("当前装备达标，等待返回库存");return;
        }
        Rect green=findGreenRerollIcon(image,parsed);
        if(green!=null){tapRect(green);status("已识别绿色重掷图标，等待确认弹窗");return;}
        pauseAutomation("装备不合格，但无法唯一定位绿色重掷按钮；已暂停且没有点击");
    }

    private void rememberItemIdentity(GearRuleEngine.Snapshot s){lastVerifiedSet=s.set;lastVerifiedRarity=s.rarity;lastVerifiedPart=s.part;lastVerifiedLevel=s.level;}
    private void hydrateResultMetadata(GearRuleEngine.Snapshot s){
        if(!lastVerifiedSet.isEmpty()){
            if(s.set.isEmpty())s.set=lastVerifiedSet;
            if(s.rarity.isEmpty())s.rarity=lastVerifiedRarity;
            if(s.part.isEmpty())s.part=lastVerifiedPart;
            if(s.level<0)s.level=lastVerifiedLevel;
        }
        int n=s.rarity.equals("传奇")?4:(s.rarity.equals("史诗")?3:-1);
        s.uncertain=s.level<0||s.set.isEmpty()||s.rarity.isEmpty()||s.part.isEmpty()||s.main.isEmpty()||n<0||s.subs.size()!=n;
    }
    private boolean validateCalibration(GearOcrParser.Parsed p,Bitmap image){
        if(!calibrationComplete())return false;
        Point[] pts=new Point[4];for(int i=0;i<4;i++){pts[i]=anchor(i,image);if(pts[i]==null)return false;}
        boolean set=false,level=false,main=false,sub=false;
        for(Map.Entry<String,Rect> e:p.labels.entrySet()){
            Rect r=e.getValue();if(r==null)continue;String text=e.getKey();
            if(near(r,pts[0],image,.20f,.14f) && (GearCatalog.detect(text)!=null||has(text,"传奇","史诗","legendary","epic")))set=true;
            if(near(r,pts[1],image,.16f,.10f) && GearRuleEngine.readLevel(text)>=0)level=true;
            if(near(r,pts[2],image,.20f,.13f) && !GearRuleEngine.normalize(text).isEmpty())main=true;
            if(near(r,pts[3],image,.24f,.20f) && !GearRuleEngine.normalize(text).isEmpty())sub=true;
        }
        return set&&level&&main&&sub;
    }
    private boolean near(Rect r,Point p,Bitmap b,float xRatio,float yRatio){return Math.abs(r.centerX()-p.x)<b.getWidth()*xRatio&&Math.abs(r.centerY()-p.y)<b.getHeight()*yRatio;}

    private GearRuleEngine.Result evaluate(GearRuleEngine.Snapshot s){
        GearRuleEngine.Config c=GearSettings.load(prefs());
        if((s.part==null||s.part.isEmpty())&&(!"全部".equals(c.part)))s.part=c.part;
        return GearRuleEngine.evaluate(s,c);
    }
    private boolean isConfirmation(GearOcrParser.Parsed p){String t=p.fullText;return has(t,"重掷")&&(has(t,"取消")||has(t,"确定")||has(t,"确认"));}
    private boolean isResultScreen(GearOcrParser.Parsed p){return has(p.fullText,"继续")&&has(p.fullText,"返回");}
    private boolean isInventoryScreen(GearOcrParser.Parsed p){
        int n=0;for(String line:p.lines)if(isLevelOneLabel(line))n++;
        return n>=2 && !has(p.fullText,"副词条")&&!has(p.fullText,"主词条")&&!has(p.fullText,"重掷");
    }
    private boolean isLevelOneLabel(String s){String x=s.replace(" ","").toLowerCase(Locale.ROOT);return x.matches(".*(?:等级|级别)1(?:级)?.*")||x.matches(".*(?:lv\\.?|level)1(?:\\D.*)?");}
    private void selectNextInventory(GearOcrParser.Parsed p,Bitmap image){
        List<Rect> candidates=new ArrayList<>();
        for(Map.Entry<String,Rect> e:p.labels.entrySet())if(isLevelOneLabel(e.getKey())&&e.getValue()!=null&&!nearProtectedText(p,e.getValue()))candidates.add(new Rect(e.getValue()));
        candidates.sort((a,b)->{int tol=Math.max(20,Math.min(a.height(),b.height()));if(Math.abs(a.centerY()-b.centerY())>tol)return Integer.compare(a.centerY(),b.centerY());return Integer.compare(a.centerX(),b.centerX());});
        List<Rect> unique=new ArrayList<>();for(Rect r:candidates){boolean seen=false;for(Rect x:unique)if(Math.abs(x.centerX()-r.centerX())<16&&Math.abs(x.centerY()-r.centerY())<16){seen=true;break;}if(!seen)unique.add(r);}
        if(unique.isEmpty()){status("库存页没有可确认的1级装备标签，不点击");return;}
        if(inventoryCursor>=unique.size()){
            Path path=new Path();path.moveTo(image.getWidth()*.52f,image.getHeight()*.82f);path.lineTo(image.getWidth()*.52f,image.getHeight()*.30f);
            GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,500)).build();dispatchGesture(g,null,null);inventoryCursor=0;awaitingInventory=false;status("当前可视库存已扫描，正在下滑寻找更多1级装备");return;
        }
        Rect candidate=unique.get(inventoryCursor);
        // Tap on the OCR level label inside the detected equipment card.
        tapRect(candidate);awaitingInventory=false;status("正在检查库存中第"+(inventoryCursor+1)+"件可见1级装备");
    }
    private boolean nearProtectedText(GearOcrParser.Parsed p,Rect r){
        for(Map.Entry<String,Rect> e:p.labels.entrySet()){
            String t=e.getKey().toLowerCase(Locale.ROOT);if(!has(t,"锁","装备中","已装备","locked","equipped","★","☆"))continue;
            Rect b=e.getValue();if(b!=null&&Math.abs(b.centerY()-r.centerY())<Math.max(42,r.height()*2))return true;
        }return false;
    }
    private Rect findButton(GearOcrParser.Parsed p,String...words){
        // Use the first exact OCR label match. Do not use substring matches inside paragraph text.
        for(Map.Entry<String,Rect> e:p.labels.entrySet()){
            String t=e.getKey().replace(" ","");if(t.length()>12)continue;
            for(String w:words)if(t.equals(w)||t.equals(w+"按钮")||(t.length()<=6&&t.contains(w)))return e.getValue();
        }
        // Some game locales use English button labels.
        for(Map.Entry<String,Rect> e:p.labels.entrySet()){
            String t=e.getKey().trim().toLowerCase(Locale.ROOT);if(t.length()>16)continue;
            for(String w:words){if(w.equals("重掷")&&(t.equals("reroll")||t.equals("re-roll")))return e.getValue();if(w.equals("继续")&&(t.equals("continue")||t.equals("next")))return e.getValue();if(w.equals("返回")&&(t.equals("back")||t.equals("return")))return e.getValue();if(w.equals("取消")&&t.equals("cancel"))return e.getValue();if(w.equals("确定")&&(t.equals("confirm")||t.equals("yes")))return e.getValue();}
        }return null;
    }
    private String buttonSummary(GearOcrParser.Parsed p){List<String> r=new ArrayList<>();for(String s:p.labels.keySet())if(has(s,"继续","返回","重掷","确定","确认","取消","continue","back","reroll"))r.add(s);return r.isEmpty()?"未检测到":"、"+String.join("、",r);}
    private boolean has(String t,String...values){if(t==null)return false;String x=t.toLowerCase(Locale.ROOT);for(String w:values)if(x.contains(w.toLowerCase(Locale.ROOT)))return true;return false;}
    private Rect findGreenRerollIcon(Bitmap b,GearOcrParser.Parsed parsed){
        int w=b.getWidth(),h=b.getHeight();Point levelAnchor=anchor(1,b);Rect levelRect=null;
        for(Map.Entry<String,Rect> e:parsed.labels.entrySet())if(e.getValue()!=null&&GearRuleEngine.readLevel(e.getKey())>=0){levelRect=e.getValue();break;}
        if(levelAnchor==null&&levelRect==null)return null;
        int cx=levelAnchor!=null?levelAnchor.x:levelRect.centerX();int cy=levelAnchor!=null?levelAnchor.y:levelRect.centerY();
        // Re-roll is adjacent to the level indicator. Constraining the search to this local band prevents unrelated green UI from being tapped.
        int left=Math.max(0,cx-(int)(w*.08f)),right=Math.min(w,cx+(int)(w*.17f));
        int top=Math.max(0,cy-(int)(h*.035f)),bottom=Math.min(h,cy+(int)(h*.035f));
        boolean[] mask=new boolean[w*h];for(int y=top;y<bottom;y+=1)for(int x=left;x<right;x+=1){int c=b.getPixel(x,y);int r=Color.red(c),g=Color.green(c),bl=Color.blue(c);if(g>112&&g>r*1.32&&g>bl*1.12)mask[y*w+x]=true;}
        boolean[] seen=new boolean[w*h];int[] q=new int[(right-left)*(bottom-top)];Rect best=null;int bestArea=0;boolean ambiguous=false;
        for(int y=top;y<bottom;y++)for(int x=left;x<right;x++){int start=y*w+x;if(!mask[start]||seen[start])continue;int hd=0,tl=0;q[tl++]=start;seen[start]=true;int minX=x,maxX=x,minY=y,maxY=y,pixels=0;
            while(hd<tl){int v=q[hd++],cx=v%w,cy=v/w;pixels++;minX=Math.min(minX,cx);maxX=Math.max(maxX,cx);minY=Math.min(minY,cy);maxY=Math.max(maxY,cy);int[] ns={v-1,v+1,v-w,v+w};for(int n:ns){if(n<0||n>=w*h||seen[n]||!mask[n])continue;int nx=n%w,ny=n/w;if(Math.abs(nx-cx)+Math.abs(ny-cy)!=1)continue;seen[n]=true;if(tl<q.length)q[tl++]=n;}}
            int bw=maxX-minX+1,bh=maxY-minY+1,area=bw*bh;if(pixels>=25&&pixels<=3200&&bw>=6&&bh>=6&&bw/(float)bh>.62f&&bw/(float)bh<1.55f){if(area>bestArea){if(bestArea>0&&area<bestArea*2)ambiguous=true;else ambiguous=false;bestArea=area;best=new Rect(minX,minY,maxX+1,maxY+1);}else if(area*2>=bestArea)ambiguous=true;}
        }
        if(best==null||ambiguous)return null;return best;
    }
    private void tapRect(Rect r){if(r!=null)dispatchTap(r.centerX(),r.centerY(),true);}
    private void dispatchTap(int x,int y,boolean debounce){
        long now=System.currentTimeMillis();if(debounce&&now-lastActionAt<650)return;lastActionAt=now;
        Path p=new Path();p.moveTo(x,y);GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,75)).build();dispatchGesture(g,null,null);
    }
    private void pauseAutomation(String msg){prefs().edit().putBoolean("auto_enabled",false).putString("status",msg).apply();status(msg);handler.removeCallbacks(loop);}
    private void status(String msg){prefs().edit().putString("status",msg).putString("last_seen",foregroundPackage).apply();}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}

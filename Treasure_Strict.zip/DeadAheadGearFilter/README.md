# 《死亡突围：僵尸战争》装备自动筛选器

AutoJs6 6.7.0 项目。通过截图、固定区域裁剪、内置 Rapid OCR、颜色采样和无障碍坐标手势完成装备筛选及重掷。不会读取 Android 控件树，不使用 `text()`、`id()`、选择器或控件点击。

> **重要：这是待设备校准的自动化项目，不是已经在你的手机上实机验证过的 APK。** 两张附件只是流程示意图，不能代替目标手机上的实际分辨率、UI 缩放和 OCR 测试。首次运行务必按下面的低风险步骤验证，不能直接把高次数挂满。

## 项目结构

```text
DeadAheadGearFilter/
├── main.js                     # 显式状态机、截图/OCR、颜色检测、手势点击
├── config.js                   # 坐标、装备词条字典、用户目标、次数上限
├── core.js                     # 归一化、最长词匹配、部位推断、规则判定
├── project.json                # 独立 APK 元信息
├── tests/logic.test.js         # 与 Android 无关的逻辑测试
└── .github/workflows/build-apk.yml
```

## 1. 先配置目标词条

打开 `config.js`，修改下面三项：

```javascript
TARGET_CORE_AFFIX: "成本",          // 核心词条：CORE_AFFIX_POOL 中 14 选 1
REQUIRED_SUB_STATS: ["魅力"],       // 必须出现的目标副词条
REQUIRE_ALL_SUB_STATS: true,         // true=全部满足；false=至少命中一项
```

当前默认的“成本 + 魅力”只是可运行示例，不代表所有装备流派的最佳词条。`REQUIRED_SUB_STATS` 至少保留一项；核心词条只能配置一个。两项都必须使用词典中的标准名称，不要写百分比数值。

`REQUIRE_GOLD_SET: true` 会要求初始装备套装名能在 `GOLD_SETS` 里识别。游戏背包仍需按你的要求事先手动筛选为“全部属性”或“幸运儿”，并保证当前列表只包含金色装备。

## 2. 区域与设备校准

所有区域都是屏幕比例坐标，不是固定像素。脚本假设游戏为横屏，背包是 **5 行 × 6 列**。

| 区域 | 默认值 | 用途 |
|---|---|---|
| A_STATS | 0.18, 0.32, 0.42, 0.55 | 装备主、副词条 OCR |
| B_SET_NAME | 0.18, 0.56, 0.40, 0.62 | 套装名称 OCR |
| C_RESET | 0.18, 0.20, 0.24, 0.26 | 作为刷新图标搜索锚点 |
| D_BAG | 0.44, 0.18, **0.76**, 0.75 | 背包网格扫描 |
| E_COMPARE | 0.32, 0.55, 0.68, 0.75 | 新装备词条对比 OCR |

坐标顺序为 `left, top, right, bottom`。注意两项基于附件截图做的安全修正：

- D_BAG 的右边界设为 `0.76`，而不是输入规格中的 `0.72`。附件第一张图实际有六列，`0.72` 会截掉最右列图标中心，网格扫描可能重复点击前一列或漏掉第六列。
- C_RESET 仍保留用户给定坐标作为锚点，但绿色刷新图标搜索会向下扩展到 `RESET_ICON_SEARCH`。附件第一张图里的绿色刷新图标中心低于 C_RESET 的原始矩形；只有颜色识别到绿色图标才点击其中心，找不到就暂停，不会按固定中心盲点。

E_COMPARE 是最需要实机校准的区域。第二张附件是上下拼接并带大量标注的示意图，不能从拼接图准确反推出你手机的单屏坐标。若新词条识别不足、识别到背景旧词条，脚本会在连续结构解析错误达到 3 次后暂停并保存截图。此时根据真实手机截图调整 `E_COMPARE`，不要关闭暂停保护。按钮“重掷 / 继续”则优先通过全屏 OCR 识别文本框中心定位，不使用固定按钮坐标；识别不到就暂停。

如果你的背包不是 5×6，必须同时修改 `BAG_GRID.rows`、`BAG_GRID.columns` 和 `MAX_BAG_CELLS`，并检查 D_BAG 边界。格子顺序为从左到右、从上到下。

## 3. 规则与状态机

部位从识别到的主词条反推：杯子、刀、表、书的主词条池按配置字典匹配。书的主词条为随机值，先 OCR 识别第一条主词条，剩余行才进入副词条集合，所以主词条不会被误计为副词条。

如果 `TARGET_CORE_AFFIX` 或任一 `REQUIRED_SUB_STATS` 与当前主词条相同，脚本直接跳过套装 OCR 和副词条 OCR，进入重置流程。核心词条缺失、目标副词条组合不满足、套装不在允许列表时，也会判为不合格。

当前装备原本已经满足所有目标规则时，脚本会记录并进入下一格，不会浪费银币重掷。

状态机顺序：

`STATE_SCAN_BAG → STATE_READ_DETAIL → STATE_JUDGE_CONFLICT → STATE_JUDGE_RULES → STATE_CLICK_RESET → STATE_WAIT_RESET_COOLDOWN → STATE_JUDGE_RESULT → STATE_CLICK_REROLL / STATE_CLICK_CONTINUE → STATE_WAIT_REROLL_COOLDOWN / STATE_WAIT_CONTINUE → STATE_NEXT_ITEM`

只有等级 1 且通过锁图标检测的装备才会打开。等级 2–12、等级 3、带锁物品跳过。OCR 连续 3 次为空或低置信度时，进入 `STATE_PAUSE` 并保存当前截图；未知部位、无法确认套装、词条解析异常、按钮识别失败都会暂停，不会猜测点击。

每次重掷前检查冷却锁和银币 OCR。点击后会等待冷却结束，并确认对比区域签名发生变化，或确认银币余额确实减少，才释放重掷锁。银币余额无法可靠 OCR 时会暂停，不会在余额未知时继续消耗。默认 `MAX_REROLLS_PER_ITEM=25`、`MAX_TOTAL_REROLLS=120`。达到硬上限或检测到银币为 0 时停止；若对比弹窗仍开着，会保留现场供人工确认，不会错误地扫描背包。

## 4. AutoJs6 运行方式

1. 安装 AutoJs6 6.7.0，导入整个项目目录，而不是只复制 `main.js`。
2. 在 AutoJs6 中先运行 `tests/logic.test.js`（也可在电脑 Node.js 环境运行），确认输出 `logic tests: OK`。
3. 在 `config.js` 中设置目标词条与次数上限。首次建议把 `MAX_REROLLS_PER_ITEM` 和 `MAX_TOTAL_REROLLS` 临时设为 `1` 或 `2`。
4. 打开游戏，切换横屏，进入装备背包，确认过滤器和金色装备列表已经设置好，并让背包界面保持可见。
5. 启动 `main.js`，授予 AutoJs6 无障碍服务和截图权限。屏幕应保持点亮，游戏必须位于前台；Android 省电策略可能中断长时间运行。
6. 首次只观察 1–2 件装备，确认格子中心、绿色刷新按钮、对比区域和“重掷 / 继续”按钮都定位正确后，再提高次数上限。

日志、极品记录和暂停截图会写到当前应用的专属外部文件目录下 `DeadAheadGearFilter/`，避免 Android 11+ 对公共存储目录的限制。主要文件是 `run.log`、`treasures.json` 和 `debug/PAUSE_*.jpg`。

## 5. 通过 GitHub Actions 构建 APK

1. 新建一个 GitHub 仓库，把 ZIP 解压后的**全部文件**上传到仓库根目录。注意保留隐藏目录 `.github/workflows/`。
2. 打开仓库的 **Actions**。
3. 选择 **Build Dead Ahead Gear Filter APK**，点击 **Run workflow**。
4. 工作流先执行 `node tests/logic.test.js`，再下载 AutoJs6 6.7.0 模板 APK 并打包项目。
5. 构建成功后打开本次运行记录，在 **Artifacts** 下载 `DeadAheadGearFilter-apk`，其中包含 `DeadAheadGearFilter.apk`。

工作流使用 AutoJs6 APK Builder 的公开 GitHub Action 示例，模板固定为 6.7.0，并使用 AutoJs6 6.7.0 模板自带的 Rapid OCR 引擎，以处理中文游戏文本；不依赖需要另行安装的 Paddle 插件。脚本启动时会先预热 Rapid OCR，模型或本地库加载失败时会在首次游戏操作前停止。APK Builder 是第三方工具，不是 GitHub 官方认证产品；上传到自己的仓库前应自行审阅其工作流与 action 源码。

## 6. 已知限制

- 当前完成了纯逻辑 Node.js 测试和静态语法检查；没有连接你的 Android 设备，未能验证真实游戏截图上的坐标、OCR 质量、权限弹窗或实际 APK 安装运行。
- 这是前台自动化，不是后台无界面挂机。游戏切到后台、屏幕分辨率/UI 缩放改变或游戏更新后，都应重新校准。
- 图标颜色判定与 OCR 阈值是保守初值，不同画质、亮度、语言、缩放可能需要调整。任何识别不可靠的情况，默认暂停而不是继续点击。
- 脚本不会自动恢复暂停现场。检查保存的暂停截图和 `run.log`，校准后重新运行。

package com.kairnos.gearreroll;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.*;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;

import java.util.*;

/**
 * 无障碍截图 + 设备端中文 OCR + 带安全闸门的自动重掷。
 *
 * 设计要点（这是与旧版最关键的差别）：
 *
 *  1. 按钮不靠 OCR 找。游戏里“重掷/继续/返回”是小字且字体特殊，OCR 经常读不到；
 *     但它们在弹窗里的位置是固定的。因此首次校准时把这四个按钮的位置一并存下来，
 *     OCR 找不到按钮时直接落到校准坐标。
 *
 *  2. 词条走“整屏 OCR + 区域二次识别”。整屏读不全时，裁出词条区放大 3 倍再识别一次，
 *     小字识别率会显著提高。
 *
 *  3. 品质不由 OCR 判断。游戏里传奇/史诗是图标和底色，不是文字，所以品质从套装目录推断。
 *
 *  4. 任何身份信息缺失（等级/套装/部位/主词条/副词条条数不对）一律暂停，绝不盲点。
 */
public class GearAutomationService extends AccessibilityService {

    private static final String PREF = "gear_settings";

    // 八个校准点：前四个是文字区域，后四个是按钮位置。
    private static final String[] ANCHOR_NAMES = {
            "套装/品质文字", "等级文字", "主词条文字", "副词条列表",
            "绿色重掷图标", "重掷确认按钮", "继续按钮", "返回按钮",
            "套装筛选按钮"
    };
    private static final int A_SET = 0, A_LEVEL = 1, A_MAIN = 2, A_SUBS = 3;
    private static final int B_ICON = 4, B_CONFIRM = 5, B_CONTINUE = 6, B_BACK = 7;
    private static final int A_FILTER = 8;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextRecognizer recognizer;
    private WindowManager wm;
    private View floating;
    private View calibrationLayer;
    private WindowManager.LayoutParams floatingParams;

    private float dragStartRawX, dragStartRawY;
    private int dragStartX, dragStartY;

    private boolean busy = false;
    private String foregroundPackage = "";
    private int inventoryCursor = 0;
    private long lastActionAt = 0;
    private int calibrationIndex = 0;
    private float screenW = 1f, screenH = 1f;

    // 从详情页记住的装备身份，供重掷结果弹窗补齐（弹窗里不显示套装名）。
    private String lastSet = "", lastRarity = "", lastPart = "", lastMain = "";
    private int lastLevel = -1;

    // 套装队列 / 自动切换筛选
    private String pendingFilterTarget = "";
    private int filterTries = 0;
    private int emptyInventoryStreak = 0;
    private long lastFilterSwitchAt = 0;

    private final Runnable loop = new Runnable() {
        @Override public void run() {
            if (enabled() && !prefs().getBoolean("inventory_safe_confirmed", false))
                pauseAutomation("安全确认未完成，自动模式已锁定");
            if (enabled() && !calibrationComplete())
                pauseAutomation("尚未完成识别校准，自动模式已锁定");
            if (enabled() && !busy && isTargetForeground()) captureAndRead(false);
            handler.postDelayed(this, 1500L);
        }
    };

    // ------------------------------------------------------------------
    // 生命周期
    // ------------------------------------------------------------------
    @Override public void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        recognizer = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        refreshScreenSize();
        createFloatingBar();
        handler.removeCallbacks(loop);
        handler.post(loop);
        status("无障碍已连接；悬浮控制条已就绪");
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        if (event.getPackageName() != null) foregroundPackage = event.getPackageName().toString();
        if (enabled()) {
            handler.removeCallbacks(loop);
            handler.postDelayed(loop, 300L);
        }
    }

    @Override public void onInterrupt() { pauseAutomation("系统中断无障碍服务"); }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        removeCalibrationLayer();
        removeFloatingBar();
        if (recognizer != null) recognizer.close();
        super.onDestroy();
    }

    private SharedPreferences prefs() { return getSharedPreferences(PREF, MODE_PRIVATE); }
    private boolean enabled() { return prefs().getBoolean("auto_enabled", false); }
    private String target() { return prefs().getString("target_package", "com.mobirate.DeadAheadTactics"); }
    private String selectedSet() { return prefs().getString("gear_set", "幸运儿"); }
    private String selectedPart() { return prefs().getString("gear_part", "全部"); }

    private void refreshScreenSize() {
        try {
            android.util.DisplayMetrics m = new android.util.DisplayMetrics();
            wm.getDefaultDisplay().getRealMetrics(m);
            screenW = m.widthPixels; screenH = m.heightPixels;
        } catch (Throwable ignored) {
            screenW = getResources().getDisplayMetrics().widthPixels;
            screenH = getResources().getDisplayMetrics().heightPixels;
        }
    }

    private boolean isTargetForeground() {
        AccessibilityNodeInfo root = null;
        try {
            root = getRootInActiveWindow();
            String pkg = root != null && root.getPackageName() != null ? root.getPackageName().toString() : foregroundPackage;
            return target().equals(pkg);
        } catch (Throwable ignored) {
            return target().equals(foregroundPackage);
        } finally {
            if (root != null) root.recycle();
        }
    }

    // ------------------------------------------------------------------
    // 悬浮控制条
    // ------------------------------------------------------------------
    private void createFloatingBar() {
        if (wm == null || floating != null) return;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(9), dp(8), dp(9), dp(8));
        panel.setAlpha(0f);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xe9222b36);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), 0x99ffffff);
        panel.setBackground(bg);
        panel.setElevation(dp(10));

        TextView heading = new TextView(this);
        heading.setText("AVALON · 按住拖动");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(10);
        heading.setTypeface(null, Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        panel.addView(heading);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        panel.addView(row);

        addFloatButton(row, "开始", () -> {
            if (!prefs().getBoolean("inventory_safe_confirmed", false)) { status("请先在主界面确认库存安全条件"); return; }
            if (!calibrationComplete()) { status("请先完成九点校准"); return; }
            pendingFilterTarget = "";
            filterTries = 0;
            emptyInventoryStreak = 0;
            prefs().edit().putBoolean("auto_enabled", true).putString("status", "已启动，等待目标游戏").apply();
            status("自动筛选已启动");
        });
        addFloatButton(row, "暂停", () -> pauseAutomation("已暂停"));
        addFloatButton(row, "停止", () -> {
            pauseAutomation("已紧急停止");
            inventoryCursor = 0;
            pendingFilterTarget = "";
            filterTries = 0;
            emptyInventoryStreak = 0;
            prefs().edit().putInt("farm_index", 0).apply();
        });
        addFloatButton(row, "校准", this::beginCalibration);
        addFloatButton(row, "测试", () -> captureAndRead(true));

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                dp(330), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = dp(72);
        floatingParams = lp;

        heading.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                dragStartRawX = event.getRawX(); dragStartRawY = event.getRawY();
                dragStartX = (int) ((screenW - dp(330)) / 2f) + floatingParams.x;
                dragStartY = floatingParams.y;
                return true;
            }
            if (event.getAction() == MotionEvent.ACTION_MOVE) {
                floatingParams.gravity = Gravity.TOP | Gravity.START;
                floatingParams.x = Math.max(0, Math.min((int) screenW - dp(330), dragStartX + (int) (event.getRawX() - dragStartRawX)));
                floatingParams.y = Math.max(0, Math.min((int) screenH - dp(72), dragStartY + (int) (event.getRawY() - dragStartRawY)));
                try { wm.updateViewLayout(panel, floatingParams); } catch (Throwable ignored) {}
                return true;
            }
            return event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL;
        });

        try {
            wm.addView(panel, lp);
            floating = panel;
            panel.animate().alpha(1f).setDuration(260).start();
        } catch (Throwable e) {
            status("悬浮控制条创建失败：" + e.getClass().getSimpleName());
        }
    }

    private void addFloatButton(LinearLayout parent, String text, Runnable action) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(11);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(9), dp(9), dp(9), dp(9));
        GradientDrawable d = new GradientDrawable();
        d.setColor(0xff455363);
        d.setCornerRadius(dp(10));
        b.setBackground(d);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(38), 1);
        p.setMargins(dp(2), dp(6), dp(2), 0);
        parent.addView(b, p);
        b.setOnClickListener(v -> action.run());
    }

    private void removeFloatingBar() {
        if (wm != null && floating != null) try { wm.removeView(floating); } catch (Throwable ignored) {}
        floating = null; floatingParams = null;
    }

    // ------------------------------------------------------------------
    // 八点校准：四个文字区域 + 四个按钮位置，都在同一件装备的详情页/弹窗上完成
    // ------------------------------------------------------------------
    private void beginCalibration() {
        if (!isTargetForeground()) { status("请先打开游戏，并进入一件装备详情页，再启动校准"); return; }
        if (calibrationLayer != null) return;
        refreshScreenSize();
        calibrationIndex = 0;

        FrameLayout layer = new FrameLayout(this);
        layer.setBackgroundColor(0x330b1320);
        layer.setClickable(true);

        TextView prompt = new TextView(this);
        prompt.setText(calibrationPrompt());
        prompt.setTextColor(Color.WHITE);
        prompt.setTextSize(15);
        prompt.setTypeface(null, Typeface.BOLD);
        prompt.setGravity(Gravity.CENTER);
        prompt.setPadding(dp(26), dp(22), dp(26), dp(22));
        GradientDrawable card = new GradientDrawable();
        card.setColor(0xe8202935);
        card.setCornerRadius(dp(20));
        card.setStroke(dp(1), 0x99ffffff);
        prompt.setBackground(card);

        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, dp(190), Gravity.CENTER);
        pp.setMargins(dp(22), 0, dp(22), 0);
        layer.addView(prompt, pp);

        layer.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                storeAnchor(calibrationIndex, event.getRawX(), event.getRawY());
                calibrationIndex++;
                if (calibrationIndex >= 9) {
                    removeCalibrationLayer();
                    status("九点校准完成。请点“测试”核对识别结果后再开始");
                } else {
                    prompt.setText(calibrationPrompt());
                    status("已记录 " + calibrationIndex + "/9：" + ANCHOR_NAMES[calibrationIndex - 1]);
                }
            }
            return true;
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        try {
            wm.addView(layer, lp);
            calibrationLayer = layer;
            status("校准开始：" + calibrationPrompt());
        } catch (Throwable e) {
            calibrationLayer = null;
            status("无法显示校准层：" + e.getClass().getSimpleName());
        }
    }

    private String calibrationPrompt() {
        switch (calibrationIndex) {
            case 0: return "① 点装备详情页里【套装名称 / 品质】所在位置";
            case 1: return "② 点【等级数字】所在位置（必须能看到“等级1”）";
            case 2: return "③ 点【主词条】那一行（最上面那条属性）";
            case 3: return "④ 点【副词条列表】区域的中间位置";
            case 4: return "⑤ 点【绿色循环箭头图标】的位置（重掷入口）";
            case 5: return "⑥ 点弹窗里的【重掷】按钮位置\n（可先点一下绿色图标让弹窗出现，再点这里）";
            case 6: return "⑦ 点结果弹窗里的【继续】按钮位置";
            case 7: return "⑧ 点结果弹窗里的【返回】按钮位置";
            default: return "⑨ 点库存页底部【显示当前套装名的筛选按钮】\n"
                    + "（就是“全部套装 / 幸运儿”那个按钮）\n\n全部完成后即可开始";
        }
    }

    private void storeAnchor(int index, float x, float y) {
        prefs().edit()
                .putFloat("anchor_x_" + index, x / Math.max(1f, screenW))
                .putFloat("anchor_y_" + index, y / Math.max(1f, screenH))
                .putBoolean("anchor_valid_" + index, true)
                .apply();
    }

    private void removeCalibrationLayer() {
        if (wm != null && calibrationLayer != null) try { wm.removeView(calibrationLayer); } catch (Throwable ignored) {}
        calibrationLayer = null;
    }

    private boolean hasAnchor(int index) { return prefs().getBoolean("anchor_valid_" + index, false); }

    private boolean calibrationComplete() {
        for (int i = 0; i < 9; i++) if (!hasAnchor(i)) return false;
        return true;
    }

    private Point anchorPoint(int index, Bitmap image) {
        if (!hasAnchor(index) || image == null) return null;
        float x = prefs().getFloat("anchor_x_" + index, .5f);
        float y = prefs().getFloat("anchor_y_" + index, .5f);
        return new Point(
                Math.max(0, Math.min(image.getWidth() - 1, (int) (x * image.getWidth()))),
                Math.max(0, Math.min(image.getHeight() - 1, (int) (y * image.getHeight()))));
    }

    // ------------------------------------------------------------------
    // 截图 + OCR（两遍：整屏，必要时区域放大二次识别）
    // ------------------------------------------------------------------
    private void captureAndRead(boolean onlyTest) {
        if (Build.VERSION.SDK_INT < 30) { pauseAutomation("需要 Android 11 或更高版本"); return; }
        if (busy) return;
        busy = true;
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult result) {
                    Bitmap bitmap = null;
                    HardwareBuffer hb = result.getHardwareBuffer();
                    try {
                        Bitmap wrapped = Bitmap.wrapHardwareBuffer(hb, result.getColorSpace());
                        if (wrapped != null) bitmap = wrapped.copy(Bitmap.Config.ARGB_8888, false);
                    } catch (Throwable ignored) {
                    } finally {
                        if (hb != null) hb.close();
                    }
                    if (bitmap == null) { busy = false; pauseAutomation("截图解码失败"); return; }
                    firstPass(bitmap, onlyTest);
                }
                @Override public void onFailure(int errorCode) {
                    busy = false;
                    if (!onlyTest) pauseAutomation("系统截图失败，错误码 " + errorCode);
                    else status("测试截图失败：" + errorCode);
                }
            });
        } catch (Throwable e) {
            busy = false;
            pauseAutomation("截图接口异常：" + e.getClass().getSimpleName());
        }
    }

    private void firstPass(Bitmap shot, boolean onlyTest) {
        recognizer.process(InputImage.fromBitmap(shot, 0))
                .addOnSuccessListener(getMainExecutor(), text -> {
                    GearOcrParser.Parsed parsed = GearOcrParser.parse(text, selectedSet(), selectedPart());
                    boolean needRegion = !onlyTest
                            && parsed.snapshot.uncertain
                            && hasAnchor(A_SUBS)
                            && !parsed.fullText.trim().isEmpty();
                    if (needRegion) {
                        secondPass(shot, parsed, onlyTest);
                    } else {
                        try { handleFrame(parsed, shot, onlyTest); }
                        catch (Throwable e) { pauseAutomation("识别流程异常：" + e.getClass().getSimpleName()); }
                        finally { shot.recycle(); busy = false; }
                    }
                })
                .addOnFailureListener(getMainExecutor(), e -> {
                    shot.recycle();
                    busy = false;
                    if (!onlyTest) pauseAutomation("离线OCR失败：" + e.getClass().getSimpleName());
                    else status("测试OCR失败：" + e.getClass().getSimpleName());
                });
    }

    /** 裁出词条区、放大 3 倍再识别一次，专门对付小字。 */
    private void secondPass(Bitmap shot, GearOcrParser.Parsed first, boolean onlyTest) {
        Rect region = regionAround(A_SUBS, shot, .30f, .26f);
        if (region == null || region.width() < 20 || region.height() < 20) {
            try { handleFrame(first, shot, onlyTest); } catch (Throwable ignored) {}
            shot.recycle(); busy = false; return;
        }
        Bitmap crop;
        Bitmap up;
        try {
            crop = Bitmap.createBitmap(shot, region.left, region.top, region.width(), region.height());
            up = Bitmap.createScaledBitmap(crop, crop.getWidth() * 3, crop.getHeight() * 3, true);
            crop.recycle();
        } catch (Throwable e) {
            try { handleFrame(first, shot, onlyTest); } catch (Throwable ignored) {}
            shot.recycle(); busy = false; return;
        }
        recognizer.process(InputImage.fromBitmap(up, 0))
                .addOnSuccessListener(getMainExecutor(), text2 -> {
                    try {
                        List<String> stats = GearOcrParser.parseStatsOnly(text2);
                        if (stats.size() >= 2) {
                            first.snapshot.main = stats.get(0);
                            first.snapshot.subs.clear();
                            first.snapshot.subs.addAll(stats.subList(1, stats.size()));
                            int expected = GearOcrParser.expectedSubs(first.snapshot.rarity);
                            first.snapshot.uncertain = expected < 0 || first.snapshot.subs.size() != expected
                                    || first.snapshot.level < 0 || first.snapshot.set.isEmpty()
                                    || first.snapshot.main.isEmpty() || first.snapshot.part.isEmpty();
                        }
                        handleFrame(first, shot, onlyTest);
                    } catch (Throwable e) {
                        pauseAutomation("二次识别异常：" + e.getClass().getSimpleName());
                    } finally {
                        up.recycle(); shot.recycle(); busy = false;
                    }
                })
                .addOnFailureListener(getMainExecutor(), e -> {
                    up.recycle(); shot.recycle(); busy = false;
                    if (!onlyTest) pauseAutomation("二次识别失败：" + e.getClass().getSimpleName());
                });
    }

    private Rect regionAround(int idx, Bitmap b, float xRatio, float yRatio) {
        Point p = anchorPoint(idx, b);
        if (p == null) return null;
        int hw = (int) (b.getWidth() * xRatio);
        int hh = (int) (b.getHeight() * yRatio);
        return new Rect(
                Math.max(0, p.x - hw), Math.max(0, p.y - hh),
                Math.min(b.getWidth(), p.x + hw), Math.min(b.getHeight(), p.y + hh));
    }

    // ------------------------------------------------------------------
    // 帧处理：识别界面状态 → 判定 → 点击
    // ------------------------------------------------------------------
    private void handleFrame(GearOcrParser.Parsed parsed, Bitmap image, boolean onlyTest) {
        if (!isTargetForeground()) {
            if (onlyTest) status("测试停止：目标游戏不在前台");
            return;
        }
        GearRuleEngine.Snapshot s = parsed.snapshot;

        if (onlyTest) {
            String summary = "识别测试\n"
                    + "套装=" + (s.set.isEmpty() ? "未识别" : s.set)
                    + "  品质=" + (s.rarity.isEmpty() ? "未识别" : s.rarity) + "\n"
                    + "等级=" + s.level + "  部位=" + (s.part.isEmpty() ? "未识别" : s.part) + "\n"
                    + "主词条=" + (s.main.isEmpty() ? "未识别" : s.main) + "\n"
                    + "副词条=" + (s.subs.isEmpty() ? "未识别" : String.join("、", s.subs)) + "\n"
                    + "按钮=" + buttonSummary(parsed) + "\n"
                    + (s.uncertain ? "状态：信息不足，自动模式会暂停" : "状态：基础信息完整");
            status(summary);
            return;
        }

        if (!enabled()) return;
        if (parsed.fullText.trim().isEmpty()) { status("等待可识别的游戏界面文字"); return; }

        // 0) 正在切换套装：优先走筛选列表流程
        if (!pendingFilterTarget.isEmpty()) { handleFilterSwitch(parsed, image); return; }

        // 1) 重掷确认弹窗
        if (isConfirmation(parsed)) {
            Rect confirm = findButton(parsed, "重掷", "确认", "确定");
            if (confirm == null) confirm = anchorRect(B_CONFIRM, image, 90);
            if (confirm != null) { tapRect(confirm); status("已点重掷确认"); return; }
            pauseAutomation("确认框出现但找不到重掷按钮");
            return;
        }

        // 2) 重掷结果弹窗
        if (isResultScreen(parsed)) {
            hydrateResultMetadata(s);
            normalizeResultStats(s);
            GearRuleEngine.Result result = evaluate(s);
            if (result.decision == GearRuleEngine.Decision.UNKNOWN) { pauseAutomation("结果页信息不完整，停止保护装备：" + result.reason); return; }
            if (result.decision == GearRuleEngine.Decision.SKIP) { pauseAutomation("结果页安全跳过：" + result.reason); return; }
            if (result.decision == GearRuleEngine.Decision.KEEP) {
                Rect back = findButton(parsed, "返回", "关闭");
                if (back == null) back = anchorRect(B_BACK, image, 90);
                if (back != null) { inventoryCursor++; lastSet = lastRarity = lastPart = lastMain = ""; lastLevel = -1; tapRect(back); status("保留：" + result.reason); return; }
                pauseAutomation("命中保留条件但找不到返回按钮");
                return;
            }
            Rect more = findButton(parsed, "继续", "下一个");
            if (more == null) more = anchorRect(B_CONTINUE, image, 90);
            if (more != null) { tapRect(more); status("未命中：" + result.reason); return; }
            pauseAutomation("未命中但找不到继续按钮");
            return;
        }

        // 3) 库存列表
        if (isInventoryScreen(parsed)) {
            lastSet = lastRarity = lastPart = lastMain = ""; lastLevel = -1;
            // 筛选没对准目标套装时，先自动切换（点“全部套装”→ 下滑找名字 → 点击）
            if (System.currentTimeMillis() - lastFilterSwitchAt > 20000
                    && !isFilterFor(parsed, image, currentTarget())) {
                lastFilterSwitchAt = System.currentTimeMillis();
                beginFilterSwitch(image);
                return;
            }
            selectNextInventory(parsed, image);
            return;
        }

        // 4) 装备详情页
        if (s.set.isEmpty()) { pauseAutomation("无法识别套装名，已暂停"); return; }
        if (!s.set.equals(selectedSet())) {
            Rect back = findButton(parsed, "返回", "关闭");
            if (back == null) back = anchorRect(B_BACK, image, 90);
            if (back != null) { inventoryCursor++; tapRect(back); status("当前是" + s.set + "，跳过"); }
            else pauseAutomation("非目标套装但找不到返回按钮");
            return;
        }

        // 记住身份，供结果弹窗使用
        if (s.level == 1 && !s.set.isEmpty() && !s.part.isEmpty()) {
            lastSet = s.set; lastRarity = s.rarity; lastPart = s.part; lastLevel = s.level;
            lastMain = s.main;
        }

        GearRuleEngine.Result result = evaluate(s);
        if (result.decision == GearRuleEngine.Decision.UNKNOWN) { pauseAutomation("识别未完整，已暂停：" + result.reason); return; }
        if (result.decision == GearRuleEngine.Decision.SKIP) {
            Rect back = findButton(parsed, "返回", "关闭");
            if (back == null) back = anchorRect(B_BACK, image, 90);
            if (back != null) { inventoryCursor++; tapRect(back); status("跳过：" + result.reason); }
            else status("跳过：" + result.reason + "；找不到返回按钮");
            return;
        }
        if (result.decision == GearRuleEngine.Decision.KEEP) {
            Rect back = findButton(parsed, "返回", "关闭");
            if (back == null) back = anchorRect(B_BACK, image, 90);
            if (back != null) { inventoryCursor++; tapRect(back); status("达标：" + result.reason); }
            else status("达标，等待返回");
            return;
        }

        // 需要重掷：先找绿色图标（颜色），再落到校准坐标
        Rect green = findGreenRerollIcon(image, parsed);
        if (green == null) green = anchorRect(B_ICON, image, 70);
        if (green != null) { tapRect(green); status("已点绿色重掷图标"); return; }
        pauseAutomation("不达标但找不到重掷按钮，未点击");
    }

    private void hydrateResultMetadata(GearRuleEngine.Snapshot s) {
        if (!lastSet.isEmpty()) {
            if (s.set.isEmpty()) s.set = lastSet;
            if (s.rarity.isEmpty()) s.rarity = lastRarity;
            if (s.part.isEmpty()) s.part = lastPart;
            if (s.level < 0) s.level = lastLevel;
        }
        if (s.rarity.isEmpty() && !s.set.isEmpty()) {
            GearCatalog.SetInfo info = GearCatalog.byName(s.set);
            if (info != null) s.rarity = info.rarity;
        }
        int n = GearOcrParser.expectedSubs(s.rarity);
        s.uncertain = s.level < 0 || s.set.isEmpty() || s.rarity.isEmpty() || s.part.isEmpty()
                || s.main.isEmpty() || n < 0 || s.subs.size() != n;
    }

    /**
     * 结果弹窗的词条布局兼容：
     *  - 若识别到「1 主 + N 副」（传奇 5 行 / 史诗 4 行）：首行是主词条。
     *  - 若只识别到 N 条（传奇 4 行 / 史诗 3 行）：弹窗只列副词条，主词条沿用详情页记住的值。
     * 其他情况一律标为不确定，让上层暂停。
     */
    private void normalizeResultStats(GearRuleEngine.Snapshot s) {
        int expected = GearOcrParser.expectedSubs(s.rarity);
        if (expected < 0) { s.uncertain = true; return; }
        List<String> all = new ArrayList<>();
        if (s.main != null && !s.main.isEmpty()) all.add(s.main);
        all.addAll(s.subs);

        if (all.size() == expected + 1) {
            s.main = all.get(0);
            s.subs.clear();
            s.subs.addAll(all.subList(1, all.size()));
        } else if (all.size() == expected) {
            if (!lastMain.isEmpty()) s.main = lastMain;
            s.subs.clear();
            s.subs.addAll(all);
        } else {
            s.uncertain = true;
            return;
        }
        s.uncertain = s.main.isEmpty() || s.subs.size() != expected || s.level < 0
                || s.set.isEmpty() || s.rarity.isEmpty() || s.part.isEmpty()
                || new HashSet<>(s.subs).size() != s.subs.size();
    }

    // ------------------------------------------------------------------
    // 套装队列 + 自动切换（点“全部套装”→ 下滑找套装名 → 点击切换）
    // ------------------------------------------------------------------
    private List<String> farmSets() {
        List<String> out = new ArrayList<>();
        String raw = prefs().getString("farm_sets", "");
        if (raw != null && !raw.trim().isEmpty()) {
            for (String x : raw.split("\\|")) if (!x.trim().isEmpty()) out.add(x.trim());
        }
        if (out.isEmpty()) out.add(prefs().getString("gear_set", "幸运儿"));
        return out;
    }

    private String currentTarget() { return prefs().getString("gear_set", "幸运儿"); }

    /** 当前套装刷完，切到队列里的下一套；队列走完就停。 */
    private void advanceSet() {
        List<String> sets = farmSets();
        int idx = prefs().getInt("farm_index", 0) + 1;
        if (idx >= sets.size()) {
            prefs().edit().putInt("farm_index", 0).apply();
            pauseAutomation("所有目标套装已刷完（共 " + sets.size() + " 套）");
            return;
        }
        String next = sets.get(idx);
        prefs().edit().putInt("farm_index", idx).putString("gear_set", next).apply();
        pendingFilterTarget = next;
        filterTries = 0;
        emptyInventoryStreak = 0;
        status("切换套装 → " + next);
    }

    /** 读底部筛选按钮上的文字（如“全部套装”“幸运儿”）。 */
    private String filterLabelNear(GearOcrParser.Parsed p, Bitmap image) {
        Point a = anchorPoint(A_FILTER, image);
        if (a == null) return "";
        String best = "";
        int bestD = Integer.MAX_VALUE;
        for (Map.Entry<String, Rect> e : p.labels.entrySet()) {
            Rect r = e.getValue();
            if (r == null) continue;
            if (e.getKey().contains("全部属性") || e.getKey().contains("物品")) continue;
            if (r.contains(a.x, a.y)) return e.getKey();
            int d = Math.abs(r.centerX() - a.x) + Math.abs(r.centerY() - a.y);
            if (d < bestD) { bestD = d; best = e.getKey(); }
        }
        return bestD < image.getWidth() * 0.22f ? best : "";
    }

    /**
     * 当前筛选是否已经对准目标套装。
     * 读不到筛选文字时返回 true（避免死循环）——真正的安全由详情页“套装必须匹配”兜底。
     */
    private boolean isFilterFor(GearOcrParser.Parsed p, Bitmap image, String target) {
        String label = filterLabelNear(p, image);
        if (label.isEmpty()) return true;
        if (label.contains("全部套装")) return false;
        GearCatalog.SetInfo info = GearCatalog.detect(label);
        if (info == null) return true;          // 读到的不是套装名，别乱动
        return info.zh.equals(target);          // 明确读到别的套装名才算不对
    }

    /** 打开套装筛选列表（相当于点“全部套装”）。 */
    private void beginFilterSwitch(Bitmap image) {
        pendingFilterTarget = currentTarget();
        filterTries = 0;
        Point a = anchorPoint(A_FILTER, image);
        if (a == null) { pauseAutomation("未校准“套装筛选按钮”，无法自动切换套装"); return; }
        dispatchTap(a.x, a.y);
        status("打开套装筛选列表，准备切到 " + pendingFilterTarget + " …");
    }

    private boolean isFilterListScreen(GearOcrParser.Parsed p) {
        if (has(p.fullText, "全部套装")) return true;
        if (has(p.fullText, "已装备") && has(p.fullText, "收藏")) return true;
        int names = 0;
        for (String line : p.lines) if (GearCatalog.detect(line) != null) names++;
        return names >= 2;
    }

    private Rect findSetInList(GearOcrParser.Parsed p, String target) {
        for (Map.Entry<String, Rect> e : p.labels.entrySet()) {
            GearCatalog.SetInfo info = GearCatalog.detect(e.getKey());
            if (info != null && info.zh.equals(target) && e.getValue() != null) return e.getValue();
        }
        for (Map.Entry<String, Rect> e : p.labels.entrySet()) {
            if (e.getValue() != null && e.getKey().length() <= 14 && e.getKey().contains(target)) return e.getValue();
        }
        return null;
    }

    /** 筛选列表流程：找目标套装 → 点击；没看到就往下滑。 */
    private void handleFilterSwitch(GearOcrParser.Parsed p, Bitmap image) {
        if (isFilterListScreen(p)) {
            Rect hit = findSetInList(p, pendingFilterTarget);
            if (hit != null) {
                tapRect(hit);
                status("已切换到套装：" + pendingFilterTarget);
                pendingFilterTarget = "";
                filterTries = 0;
                emptyInventoryStreak = 0;
                lastFilterSwitchAt = System.currentTimeMillis();
                return;
            }
            filterTries++;
            if (filterTries > 8) {
                String t = pendingFilterTarget;
                pendingFilterTarget = "";
                pauseAutomation("在套装列表里找不到“" + t + "”，已暂停");
                return;
            }
            float x = image.getWidth() * .68f;
            Path path = new Path();
            path.moveTo(x, image.getHeight() * .74f);
            path.lineTo(x, image.getHeight() * .30f);
            GestureDescription g = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, 420)).build();
            dispatchGesture(g, null, null);
            status("列表里没看到“" + pendingFilterTarget + "”，下滑查找…(" + filterTries + "/8)");
            return;
        }
        // 列表还没弹出来，再点一次筛选按钮
        filterTries++;
        if (filterTries > 4) {
            pendingFilterTarget = "";
            pauseAutomation("无法打开套装筛选列表，已暂停");
            return;
        }
        Point a = anchorPoint(A_FILTER, image);
        if (a != null) { dispatchTap(a.x, a.y); status("再次尝试打开套装筛选列表…"); }
        else pauseAutomation("未校准套装筛选按钮");
    }

    private void swipeInventory(Bitmap image) {
        Path path = new Path();
        path.moveTo(image.getWidth() * .52f, image.getHeight() * .82f);
        path.lineTo(image.getWidth() * .52f, image.getHeight() * .30f);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 500)).build();
        dispatchGesture(g, null, null);
    }

    private GearRuleEngine.Result evaluate(GearRuleEngine.Snapshot s) {
        GearRuleEngine.Config c = GearSettings.load(prefs());
        if ((s.part == null || s.part.isEmpty()) && !"全部".equals(c.part)) s.part = c.part;
        return GearRuleEngine.evaluate(s, c);
    }

    // ------------------------------------------------------------------
    // 界面状态判定
    // ------------------------------------------------------------------
    private boolean isConfirmation(GearOcrParser.Parsed p) {
        String t = p.fullText;
        // 优先用弹窗里较长、较容易识别的正文做判断：
        // 确认框有“该物品将被用于交换……”，结果框有“新统计”，这两个都比按钮小字可靠。
        if (has(t, "重掷结果") || has(t, "新统计") || has(t, "继续")) return false;
        return has(t, "该物品将被用于交换") || has(t, "重掷") || has(t, "确定", "确认");
    }

    private boolean isResultScreen(GearOcrParser.Parsed p) {
        String t = p.fullText;
        if (has(t, "重掷结果") || has(t, "新统计")) return true;
        return has(t, "继续") && !has(t, "套装");
    }

    private boolean isInventoryScreen(GearOcrParser.Parsed p) {
        int n = 0;
        for (String line : p.lines) if (isLevelLabel(line)) n++;
        return n >= 2 && !has(p.fullText, "副词条") && !has(p.fullText, "主词条")
                && !has(p.fullText, "重掷") && !has(p.fullText, "套装");
    }

    private boolean isLevelLabel(String s) {
        String x = s.replace(" ", "").toLowerCase(Locale.ROOT);
        return x.matches(".*(?:等级|级别)\\d+.*") || x.matches(".*(?:lv\\.?|level)\\d+.*");
    }

    private boolean isLevelOneLabel(String s) {
        String x = s.replace(" ", "").toLowerCase(Locale.ROOT);
        return x.matches(".*(?:等级|级别)1(?:级)?.*") || x.matches(".*(?:lv\\.?|level)1(?:\\D.*)?");
    }

    // ------------------------------------------------------------------
    // 库存遍历
    // ------------------------------------------------------------------
    private void selectNextInventory(GearOcrParser.Parsed p, Bitmap image) {
        List<Rect> candidates = new ArrayList<>();
        for (Map.Entry<String, Rect> e : p.labels.entrySet()) {
            if (isLevelOneLabel(e.getKey()) && e.getValue() != null && !nearProtectedText(p, e.getValue())) {
                candidates.add(new Rect(e.getValue()));
            }
        }
        candidates.sort((a, b) -> {
            int tol = Math.max(20, Math.min(a.height(), b.height()));
            if (Math.abs(a.centerY() - b.centerY()) > tol) return Integer.compare(a.centerY(), b.centerY());
            return Integer.compare(a.centerX(), b.centerX());
        });
        List<Rect> unique = new ArrayList<>();
        for (Rect r : candidates) {
            boolean seen = false;
            for (Rect x : unique) if (Math.abs(x.centerX() - r.centerX()) < 16 && Math.abs(x.centerY() - r.centerY()) < 16) { seen = true; break; }
            if (!seen) unique.add(r);
        }
        if (unique.isEmpty()) {
            emptyInventoryStreak++;
            if (emptyInventoryStreak >= 3) {
                emptyInventoryStreak = 0;
                inventoryCursor = 0;
                advanceSet();
            } else {
                swipeInventory(image);
                status("未找到 1 级装备，下滑查找…(" + emptyInventoryStreak + "/3)");
            }
            return;
        }
        emptyInventoryStreak = 0;
        if (inventoryCursor >= unique.size()) {
            swipeInventory(image);
            inventoryCursor = 0;
            status("已扫描完当前可见库存，正在下滑");
            return;
        }
        Rect candidate = unique.get(inventoryCursor);
        tapRect(candidate);
        status("检查第 " + (inventoryCursor + 1) + " 件 1 级装备");
    }

    private boolean nearProtectedText(GearOcrParser.Parsed p, Rect r) {
        for (Map.Entry<String, Rect> e : p.labels.entrySet()) {
            String t = e.getKey().toLowerCase(Locale.ROOT);
            if (!has(t, "锁", "装备中", "已装备", "locked", "equipped", "★", "☆")) continue;
            Rect b = e.getValue();
            if (b != null && Math.abs(b.centerY() - r.centerY()) < Math.max(42, r.height() * 2)) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------
    // 按钮定位：OCR 优先，校准坐标兜底
    // ------------------------------------------------------------------
    private Rect findButton(GearOcrParser.Parsed p, String... words) {
        for (Map.Entry<String, Rect> e : p.labels.entrySet()) {
            String t = e.getKey().replace(" ", "");
            if (t.length() > 12) continue;
            for (String w : words) {
                if (t.equals(w) || t.equals(w + "按钮") || (t.length() <= 6 && t.contains(w))) return e.getValue();
            }
        }
        for (Map.Entry<String, Rect> e : p.labels.entrySet()) {
            String t = e.getKey().trim().toLowerCase(Locale.ROOT);
            if (t.length() > 16) continue;
            for (String w : words) {
                if (w.equals("重掷") && (t.equals("reroll") || t.equals("re-roll"))) return e.getValue();
                if (w.equals("继续") && (t.equals("continue") || t.equals("next"))) return e.getValue();
                if (w.equals("返回") && (t.equals("back") || t.equals("return"))) return e.getValue();
                if (w.equals("取消") && t.equals("cancel")) return e.getValue();
                if (w.equals("确定") && (t.equals("confirm") || t.equals("yes"))) return e.getValue();
            }
        }
        return null;
    }

    private Rect anchorRect(int idx, Bitmap image, int radius) {
        Point p = anchorPoint(idx, image);
        if (p == null) return null;
        return new Rect(p.x - radius, p.y - radius, p.x + radius, p.y + radius);
    }

    private String buttonSummary(GearOcrParser.Parsed p) {
        List<String> r = new ArrayList<>();
        for (String s : p.labels.keySet())
            if (has(s, "继续", "返回", "重掷", "确定", "确认", "取消", "continue", "back", "reroll")) r.add(s);
        return r.isEmpty() ? "未检测到" : String.join("、", r);
    }

    /**
     * 绿色重掷图标定位：在“等级文字”附近的窄带里找绿色连通块。
     * 找不到就返回 null，由调用方回退到校准坐标。
     */
    private Rect findGreenRerollIcon(Bitmap b, GearOcrParser.Parsed parsed) {
        int w = b.getWidth(), h = b.getHeight();
        Point levelAnchor = anchorPoint(A_LEVEL, b);
        Rect levelRect = null;
        for (Map.Entry<String, Rect> e : parsed.labels.entrySet()) {
            if (e.getValue() != null && GearRuleEngine.readLevel(e.getKey()) >= 0) { levelRect = e.getValue(); break; }
        }
        if (levelAnchor == null && levelRect == null) return null;
        int cx = levelAnchor != null ? levelAnchor.x : levelRect.centerX();
        int cy = levelAnchor != null ? levelAnchor.y : levelRect.centerY();

        int left = Math.max(0, cx - (int) (w * .08f));
        int right = Math.min(w, cx + (int) (w * .17f));
        int top = Math.max(0, cy - (int) (h * .035f));
        int bottom = Math.min(h, cy + (int) (h * .035f));

        boolean[] mask = new boolean[w * h];
        for (int y = top; y < bottom; y++)
            for (int x = left; x < right; x++) {
                int c = b.getPixel(x, y);
                int r = Color.red(c), g = Color.green(c), bl = Color.blue(c);
                if (g > 112 && g > r * 1.32 && g > bl * 1.12) mask[y * w + x] = true;
            }

        boolean[] seen = new boolean[w * h];
        int[] q = new int[(right - left) * (bottom - top)];
        Rect best = null;
        int bestArea = 0;
        boolean ambiguous = false;

        for (int y = top; y < bottom; y++)
            for (int x = left; x < right; x++) {
                int start = y * w + x;
                if (!mask[start] || seen[start]) continue;
                int hd = 0, tl = 0;
                q[tl++] = start;
                seen[start] = true;
                int minX = x, maxX = x, minY = y, maxY = y, pixels = 0;
                while (hd < tl) {
                    int v = q[hd++], vx = v % w, vy = v / w;
                    pixels++;
                    minX = Math.min(minX, vx); maxX = Math.max(maxX, vx);
                    minY = Math.min(minY, vy); maxY = Math.max(maxY, vy);
                    int[] ns = {v - 1, v + 1, v - w, v + w};
                    for (int n : ns) {
                        if (n < 0 || n >= w * h || seen[n] || !mask[n]) continue;
                        int nx = n % w, ny = n / w;
                        if (Math.abs(nx - vx) + Math.abs(ny - vy) != 1) continue;
                        seen[n] = true;
                        if (tl < q.length) q[tl++] = n;
                    }
                }
                int bw = maxX - minX + 1, bh = maxY - minY + 1, area = bw * bh;
                if (pixels >= 25 && pixels <= 3200 && bw >= 6 && bh >= 6
                        && bw / (float) bh > .62f && bw / (float) bh < 1.55f) {
                    if (area > bestArea) {
                        if (bestArea > 0 && area < bestArea * 2) ambiguous = true; else ambiguous = false;
                        bestArea = area;
                        best = new Rect(minX, minY, maxX + 1, maxY + 1);
                    } else if (area * 2 >= bestArea) {
                        ambiguous = true;
                    }
                }
            }
        if (best == null || ambiguous) return null;
        return best;
    }

    // ------------------------------------------------------------------
    // 点击
    // ------------------------------------------------------------------
    private void tapRect(Rect r) { if (r != null) dispatchTap(r.centerX(), r.centerY()); }

    private void dispatchTap(int x, int y) {
        long now = System.currentTimeMillis();
        if (now - lastActionAt < 650) return;
        lastActionAt = now;
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 75)).build();
        dispatchGesture(g, null, null);
    }

    // ------------------------------------------------------------------
    // 状态
    // ------------------------------------------------------------------
    private void pauseAutomation(String msg) {
        prefs().edit().putBoolean("auto_enabled", false).putString("status", msg).apply();
        status(msg);
        handler.removeCallbacks(loop);
    }

    private void status(String msg) {
        prefs().edit().putString("status", msg).putString("last_seen", foregroundPackage).apply();
    }

    private boolean has(String t, String... values) {
        if (t == null) return false;
        String x = t.toLowerCase(Locale.ROOT);
        for (String w : values) if (x.contains(w.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }
}

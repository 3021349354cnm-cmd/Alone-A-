@echo off
setlocal
set VERSION=8.11.1
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set BASE=%GRADLE_USER_HOME%\distributions
set INSTALL=%BASE%\gradle-%VERSION%
if exist "%INSTALL%\bin\gradle.bat" goto run
if not exist "%BASE%" mkdir "%BASE%"
set TMP=%TEMP%\gradle-bootstrap-%RANDOM%
mkdir "%TMP%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%TMP%\gradle.zip'; Expand-Archive -LiteralPath '%TMP%\gradle.zip' -DestinationPath '%TMP%' -Force"
if errorlevel 1 exit /b 1
move "%TMP%\gradle-%VERSION%" "%INSTALL%" >nul
rmdir /s /q "%TMP%"
:run
call "%INSTALL%\bin\gradle.bat" %*
endlocal

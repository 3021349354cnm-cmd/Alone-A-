plugins { id("com.android.application") }

android {
    namespace = "com.kairnos.gearreroll"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kairnos.avalon"
        minSdk = 30
        targetSdk = 35
        versionCode = 7
        versionName = "0.4.1"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("fixed.jks")
            storePassword = "android"
            keyAlias = "avalon"
            keyPassword = "android"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Bundled on-device Chinese OCR; the app does not upload screenshots.
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
    testImplementation("junit:junit:4.13.2")
}

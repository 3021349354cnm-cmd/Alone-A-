/*
 * 《死亡突围：僵尸战争》装备重置筛选器配置
 * 修改本文件后再运行 main.js。
 * 所有区域均为相对屏幕比例坐标：0.0 ~ 1.0。
 */
var CONFIG = {
  APP_NAME: "Dead Ahead Gear Filter",
  VERSION: "1.0.0",

  /* OCR 引擎：中文游戏文本优先使用 AutoJs6 6.7.0 内置 Rapid OCR，不依赖 Paddle 插件。 */
  OCR_MODE: "rapid",
  OCR_MIN_CONFIDENCE: 0.58,
  OCR_MAX_EMPTY_STREAK: 3,
  OCR_RETRY_DELAY_MS: 350,

  /* 区域 A-E：以用户给出的比例坐标为基准；D 右边界按附件六列网格校正。 */
  REGIONS: {
    A_STATS:       { left: 0.18, top: 0.32, right: 0.42, bottom: 0.55 },
    B_SET_NAME:    { left: 0.18, top: 0.56, right: 0.40, bottom: 0.62 },
    C_RESET:       { left: 0.18, top: 0.20, right: 0.24, bottom: 0.26 },
    /* 附图中的绿色刷新图标略低于给定 C 区；仅在左侧 C 邻近区域做绿色图标校验。 */
    RESET_ICON_SEARCH: { left: 0.17, top: 0.18, right: 0.29, bottom: 0.37 },
    /* 右边界按附件截图扩至 0.76：原 0.72 会截掉最右侧第 6 列图标中心。 */
    D_BAG:         { left: 0.44, top: 0.18, right: 0.76, bottom: 0.75 },
    E_REROLL:      { left: 0.50, top: 0.75, right: 0.65, bottom: 0.82 },
    E_CONTINUE:    { left: 0.40, top: 0.75, right: 0.50, bottom: 0.82 },
    E_COMPARE:     { left: 0.32, top: 0.55, right: 0.68, bottom: 0.75 },

    /* 可选辅助识别区；无法识别标题时，使用主词条池反推部位。 */
    TYPE_TITLE:    { left: 0.28, top: 0.12, right: 0.46, bottom: 0.25 },
    COIN_BALANCE:  { left: 0.84, top: 0.08, right: 0.985, bottom: 0.15 }
  },

  /* 背包 D 区按截图默认 5 行 × 6 列，扫描顺序：先左到右，再上到下。 */
  BAG_GRID: {
    rows: 5,
    columns: 6,
    insetRatio: 0.035
  },

  /* 只重置等级 1；等级 2-12、锁定物品一律跳过。 */
  LEVEL_ALLOWED: [1],
  MAX_BAG_CELLS: 30,

  /* 装备部位主词条池：严格按用户提供的词典。 */
  EQUIPMENT_MAIN_STATS: {
    "杯子": ["生命值"],
    "刀": ["近战伤害", "远程伤害"],
    "表": ["准备时间", "敏捷"],
    "书": ["暴击机会", "暴击伤害", "远程伤害百分比", "近战伤害百分比", "生命值百分比"]
  },

  GOLD_SETS: [
    "猎人", "军人", "幸运儿", "绅士", "健身", "老大", "瑞士", "外科",
    "职业杀手", "赌博", "消防员", "童子军", "大男孩", "爱国者", "破冰者",
    "独狼", "齿轮系", "针垫", "碳纤", "尖刺", "圣物"
  ],

  SUB_STATS: [
    "生命值", "生命值百分比", "近战伤害", "近战伤害百分比", "远程伤害",
    "远程伤害百分比", "暴击机会", "暴击伤害", "敏捷", "准备时间", "射程",
    "成本", "勇气", "魅力"
  ],

  /* 14 选 1。默认值仅作为示例，启动前应改为自己的目标核心词条。 */
  CORE_AFFIX_POOL: [
    "成本", "暴击伤害", "远程伤害百分比", "近战伤害百分比", "生命值百分比",
    "生命值", "近战伤害", "远程伤害", "暴击机会", "敏捷", "准备时间",
    "射程", "勇气", "魅力"
  ],

  /* 用户自定义目标：核心词条必须恰好 1 个；副词条默认要求全部满足。 */
  TARGET_CORE_AFFIX: "成本",
  REQUIRED_SUB_STATS: ["魅力"],
  REQUIRE_ALL_SUB_STATS: true,
  REQUIRE_GOLD_SET: true,

  /* 每件装备与整次脚本的硬上限，避免金币被无限消耗。 */
  MAX_REROLLS_PER_ITEM: 25,
  MAX_TOTAL_REROLLS: 120,

  /* 动作节流 / 等待超时。 */
  RESET_COOLDOWN_MS: 1500,
  REROLL_COOLDOWN_MS: 1800,
  CLICK_DEBOUNCE_MS: 450,
  POPUP_TIMEOUT_MS: 9000,
  RESULT_CHANGE_TIMEOUT_MS: 12000,
  POLL_INTERVAL_MS: 450,

  /* 空格检测：装备图标通常带金色或蓝色像素，避免对空格做空 OCR。 */
  BAG_REQUIRE_GEAR_ICON: true,
  BAG_MIN_GEAR_COLOR_PIXELS: 10,
  BAG_COLOR_SAMPLE_STEP: 3,

  /* 固定按钮回退默认关闭；必须先 OCR 到按钮文字才会点。 */
  ALLOW_FIXED_BUTTON_FALLBACK: false,

  /* 锁图标：白色小锁通常位于装备格右上角。 */
  LOCK_DETECT: {
    enabled: true,
    roiLeft: 0.72,
    roiTop: 0.03,
    roiRight: 0.98,
    roiBottom: 0.31,
    brightnessMin: 190,
    channelDeltaMax: 55,
    minWhitePixels: 5,
    sampleStep: 2
  },

  /* 如 OCR 无法从装备主词条反推部位，可按背包格手动指定，例如 {"0,2":"书"}。 */
  MANUAL_PART_BY_CELL: {},

  /* OCR / 区域无法确认时，默认暂停并保存截图；绝不猜测、绝不盲点。 */
  PAUSE_ON_UNKNOWN_PART: true,
  PAUSE_ON_UNKNOWN_SET: true,
  PAUSE_ON_UNKNOWN_LEVEL: true,
  PAUSE_ON_UNKNOWN_DIALOG: true,

  /* 日志与截图保存位置。 */
  /* 留空时自动写入当前 APK 的 app-specific 外部目录，适配 Android 11+ 分区存储。 */
  OUTPUT_DIR: "",
  DEBUG_SAVE_EVERY_SCREEN: false,
  KEEP_SCREEN_ON: true
};

module.exports = CONFIG;

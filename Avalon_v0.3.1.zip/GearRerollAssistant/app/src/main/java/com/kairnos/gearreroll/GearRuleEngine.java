package com.kairnos.gearreroll;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Conservative rule evaluator. UNKNOWN always means no click. */
public final class GearRuleEngine {
    private GearRuleEngine() {}
    public enum Decision { KEEP, REROLL, SKIP, UNKNOWN }
    public static final class Snapshot {
        public String set="", rarity="", part="", main="";
        public final List<String> subs=new ArrayList<>();
        public int level=-1;
        public boolean protectedItem=false, uncertain=false;
        public String raw="";
    }
    public static final class Config {
        public final Set<String> wanted=new LinkedHashSet<>();
        public final Set<String> must=new LinkedHashSet<>();
        public final Set<String> allowedMain=new LinkedHashSet<>();
        public int minHits=0;
        public boolean usePreset=true;
        public String part="全部";
    }
    public static final class Result {
        public final Decision decision;
        public final String reason;
        public final int matched, expected;
        Result(Decision d,String r,int m,int e){decision=d;reason=r;matched=m;expected=e;}
    }

    public static String normalize(String raw) {
        if (raw == null) return "";
        String s=raw.toLowerCase(Locale.ROOT).replace(" ", "").replace("：", ":");
        // Remove numeric values, not the percentage marker.
        s=s.replaceAll("[+＋−-]?\\d+(?:[.,]\\d+)?", "");
        s=s.replace("％", "%").replace("百分之", "%");
        if (contains(s,"固定生命值","生命值","hp","health")) {
            if (contains(s,"%","百分比","percent")) return "生命值百分比";
            return "固定生命值";
        }
        if (contains(s,"近战伤害","近战攻击伤害","meleedmg","meleedamage"))
            return contains(s,"%","百分比","percent") ? "近战伤害百分比" : "固定近战伤害";
        if (contains(s,"远程伤害","射击伤害","远程攻击伤害","rangeddmg","rangeddamage"))
            return contains(s,"%","百分比","percent") ? "远程伤害百分比" : "固定远程伤害";
        if (contains(s,"暴击几率","暴击率","暴击机会","暴击概率","critchance")) return "暴击几率";
        if (contains(s,"暴击伤害","爆伤","暴击伤害加成","critdamage","critdmg")) return "暴击伤害";
        if (contains(s,"准备时间降低","准备时间","部署时间降低","preptime","preparationtime")) return "准备时间降低";
        if (contains(s,"冷却时间","冷却","cooldown")) return "冷却时间";
        if (contains(s,"敏捷度","敏捷","agility")) return "敏捷度";
        if (contains(s,"魅力","charisma")) return "魅力";
        if (contains(s,"勇气","valor")) return "勇气";
        if (contains(s,"费用降低","成本降低","费用","成本","cost")) return "费用降低";
        if (contains(s,"射程","range")) return contains(s,"%","百分比","percent") ? "射程百分比" : "固定射程";
        return "";
    }
    private static boolean contains(String s,String... needles){for(String n:needles)if(s.contains(n.toLowerCase(Locale.ROOT)))return true;return false;}
    public static int readLevel(String text) {
        if (text == null) return -1;
        Matcher m=Pattern.compile("(?:等级|级别|lv\\.?|level)\\s*[:：]?\\s*(\\d+)",Pattern.CASE_INSENSITIVE).matcher(text);
        if(m.find()) try{return Integer.parseInt(m.group(1));}catch(Exception ignored){}
        return -1;
    }
    public static Result evaluate(Snapshot s, Config c) {
        if (s==null || c==null || s.uncertain || s.level<0 || s.set.isEmpty() || s.rarity.isEmpty() || s.main.isEmpty() || s.part.isEmpty())
            return result(Decision.UNKNOWN,"装备身份、等级、品质、部位或主词条未完整识别",0,0);
        if (s.level!=1) return result(Decision.SKIP,"只允许重掷1级装备",0,0);
        if (s.protectedItem) return result(Decision.SKIP,"检测到锁定、已装备或受保护标记",0,0);
        GearCatalog.SetInfo info=GearCatalog.byName(s.set);
        if(info==null) return result(Decision.UNKNOWN,"套装不在24套目标清单中",0,0);
        if(!info.rarity.equals(s.rarity)) return result(Decision.SKIP,"品质与目标套装不符：此套装目标品质为"+info.rarity,0,0);
        int expected=s.rarity.equals("传奇")?4:(s.rarity.equals("史诗")?3:-1);
        if(expected<0 || s.subs.size()!=expected) return result(Decision.UNKNOWN,"副词条数量异常：预期"+expected+"条，识别到"+s.subs.size()+"条",0,expected);
        String main=normalize(s.main);
        if(main.isEmpty()) return result(Decision.UNKNOWN,"主词条无法分类",0,expected);
        if(!"全部".equals(c.part) && !c.part.equals(s.part)) return result(Decision.SKIP,"当前部位不是所选的"+c.part,0,expected);
        Set<String> seen=new HashSet<>(); seen.add(main);
        Set<String> subSet=new LinkedHashSet<>();
        for(String raw:s.subs){
            String key=normalize(raw);
            if(key.isEmpty()) return result(Decision.UNKNOWN,"发现未识别副词条："+raw,0,expected);
            if(!seen.add(key)) return result(Decision.REROLL,"主副词条或副词条之间存在重复",0,expected);
            subSet.add(key);
        }
        Set<String> wanted=new LinkedHashSet<>(), must=new LinkedHashSet<>();
        if(c.usePreset) applyPreset(s.set,wanted,must);
        wanted.addAll(c.wanted);
        must.addAll(c.must);
        wanted.addAll(must);
        if(wanted.isEmpty()) return result(Decision.UNKNOWN,"尚未设置想要词条；请在筛选配置中至少选择一项",0,expected);
        if(!subSet.containsAll(must)){
            Set<String> miss=new LinkedHashSet<>(must);miss.removeAll(subSet);
            return result(Decision.REROLL,"缺少必带词条："+String.join("、",miss),countHits(subSet,wanted),expected);
        }
        if(!c.allowedMain.isEmpty() && !c.allowedMain.contains(main)) return result(Decision.REROLL,"主词条不在允许列表："+main,countHits(subSet,wanted),expected);
        if(c.usePreset){
            String presetReason=presetConflict(s,subSet,main);
            if(presetReason!=null)return result(Decision.REROLL,presetReason,countHits(subSet,wanted),expected);
        }
        int hits=countHits(subSet,wanted);
        int min=c.minHits>0?c.minHits:(s.rarity.equals("传奇")?3:3);
        if(min>expected) min=expected;
        if(hits<min) return result(Decision.REROLL,"想要词条命中不足："+hits+"/"+min, hits, expected);
        return result(Decision.KEEP,"符合保留条件：命中"+hits+"条，副词条"+expected+"条",hits,expected);
    }
    private static int countHits(Set<String> got,Set<String>want){int n=0;for(String s:got)if(want.contains(s))n++;return n;}
    private static Result result(Decision d,String s,int m,int e){return new Result(d,s,m,e);}

    private static void applyPreset(String set,Set<String>wanted,Set<String>must){
        switch(set){
            case "绅士": Collections.addAll(wanted,"费用降低","暴击伤害","固定近战伤害","近战伤害百分比","固定远程伤害","远程伤害百分比","冷却时间","准备时间降低");must.add("费用降低");break;
            case "爱国者": Collections.addAll(wanted,"固定远程伤害","远程伤害百分比","暴击伤害","暴击几率","射程百分比");break;
            case "幸运儿": Collections.addAll(wanted,"生命值百分比","固定生命值","敏捷度","费用降低","准备时间降低");must.add("费用降低");break;
            case "童子军": Collections.addAll(wanted,"生命值百分比","固定生命值","固定近战伤害","近战伤害百分比","冷却时间","费用降低");must.add("费用降低");break;
            case "战术": Collections.addAll(wanted,"固定射程","射程百分比","固定远程伤害","远程伤害百分比","费用降低","暴击伤害");must.add("费用降低");break;
            default: // For other sets, use a broad, user-editable general-purpose profile.
                wanted.addAll(GearCatalog.STATS);
                break;
        }
    }
    private static String presetConflict(Snapshot s,Set<String> subs,String main){
        if("绅士".equals(s.set)){
            boolean melee=containsPrefix(subs,"固定近战伤害","近战伤害百分比")||main.contains("近战");
            boolean ranged=containsPrefix(subs,"固定远程伤害","远程伤害百分比")||main.contains("远程");
            if(melee&&ranged)return "绅士套装不能混合近战与远程词条";
            if("表".equals(s.part) && !(main.equals("冷却时间")||main.equals("敏捷度")))return "绅士手表主词条必须为冷却或敏捷";
            if("书".equals(s.part) && !(main.equals("暴击几率")||main.equals("近战伤害百分比")))return "绅士书籍主词条不符合手册要求";
        }
        if("爱国者".equals(s.set)){
            if("表".equals(s.part)&&!main.equals("敏捷度"))return "爱国者手表主词条必须为敏捷度";
            if("书".equals(s.part)&&!(main.equals("远程伤害百分比")||main.equals("暴击几率")||main.equals("暴击伤害")))return "爱国者书籍主词条不符合手册要求";
        }
        if("幸运儿".equals(s.set)&&"书".equals(s.part)&&!main.equals("生命值百分比"))return "幸运儿书籍主词条必须为生命值百分比";
        if("童子军".equals(s.set)&&"书".equals(s.part)&&!main.equals("近战伤害百分比"))return "童子军书籍主词条必须为近战伤害百分比";
        return null;
    }
    private static boolean containsPrefix(Set<String>s,String... vals){for(String v:vals)if(s.contains(v))return true;return false;}
}

package com.kairnos.gearreroll;

import java.util.*;

/** The 24 target sets requested by the user: 22 legendary + Builder/Tactical epic. */
public final class GearCatalog {
    private GearCatalog() {}
    public static final class SetInfo {
        public final String zh, en, rarity, aliases, bonus;
        public SetInfo(String zh, String en, String rarity, String aliases, String bonus) {
            this.zh=zh; this.en=en; this.rarity=rarity; this.aliases=aliases; this.bonus=bonus;
        }
        public String searchable() { return (zh+"|"+en+"|"+aliases).toLowerCase(Locale.ROOT); }
    }
    private static final List<SetInfo> SETS = Collections.unmodifiableList(Arrays.asList(
        new SetInfo("军用", "Military", "传奇", "军队|军事", "远程单位有概率在一次射击中发射双倍子弹"),
        new SetInfo("猎人", "Hunter", "传奇", "猎手", "与目标距离越远，主伤害加成越高"),
        new SetInfo("绅士", "Gentleman", "传奇", "绅士", "暴击后短时间提高主伤害"),
        new SetInfo("外科", "Surgery", "传奇", "外科医生|Surgeon", "低生命值时提高主伤害"),
        new SetInfo("健身", "Fitness", "传奇", "健身者", "提高单位攻击与索敌时的稳定性"),
        new SetInfo("瑞士制造", "SwissMade", "传奇", "瑞士|Swiss Made", "提高主伤害"),
        new SetInfo("首领", "Boss", "传奇", "领袖", "单位入场时短暂提高全队主伤害"),
        new SetInfo("杀手", "Hitman", "传奇", "刺客", "生命值低于满值时提高暴击伤害"),
        new SetInfo("赌徒", "Gambling", "传奇", "赌博|赌棍", "受伤后提高暴击几率"),
        new SetInfo("消防员", "Firefighter", "传奇", "消防", "提高对燃烧目标的伤害"),
        new SetInfo("幸运儿", "Lucky Guy", "传奇", "幸运|LuckyGuy", "首次受到致命伤害时保留1点生命"),
        new SetInfo("童子军", "Scout", "传奇", "侦察兵|童子军", "击败敌人后获得短暂护盾"),
        new SetInfo("大男孩", "Big Boy", "传奇", "巨人|BigBoy", "根据生命值提高伤害"),
        new SetInfo("爱国者", "Patriot", "传奇", "爱国者", "队友阵亡时提高主伤害"),
        new SetInfo("破冰者", "Ice Breaker", "传奇", "破冰|IceBreaker", "提高对眩晕或冰冻敌人的伤害"),
        new SetInfo("独狼", "Lone Wolf", "传奇", "孤狼|LoneWolf", "战场单位越少，伤害加成越高"),
        new SetInfo("齿轮列车", "Gear Train", "传奇", "齿轮|GearTrain", "连续射击逐步提高远程伤害"),
        new SetInfo("针垫", "Pincushion", "传奇", "针垫|Pincushion", "受到攻击后提高伤害"),
        new SetInfo("碳纤维", "Carbon", "传奇", "碳|Carbon", "降低前几次受到的伤害"),
        new SetInfo("穿刺", "Piercing", "传奇", "穿透|Piercing", "子弹穿透首个目标并伤害后方目标"),
        new SetInfo("创伤包", "Trauma Kit", "传奇", "创伤|急救包|TraumaKit", "提高对流血敌人的主伤害"),
        new SetInfo("遗物", "Relics", "传奇", "遗物|Relic", "根据魅力提高前排友军伤害"),
        new SetInfo("建筑", "Builder", "史诗", "建筑工|Builder", "有概率阻止受到的伤害"),
        new SetInfo("战术", "Tactical", "史诗", "战术", "使子弹无视部分敌方子弹抗性")
    ));

    // The UI exposes the fourteen current in-game substat categories.
    public static final List<String> STATS = Collections.unmodifiableList(Arrays.asList(
        "固定生命值", "固定近战伤害", "固定远程伤害", "生命值百分比", "近战伤害百分比",
        "远程伤害百分比", "暴击几率", "暴击伤害", "准备时间降低", "敏捷度",
        "魅力", "勇气", "射程百分比", "费用降低"
    ));
    // Legacy/manual-only terms remain parseable for the five hand-book presets,
    // but are deliberately not shown as additional current-game substat options.
    public static final List<String> COMPATIBILITY_STATS = Collections.unmodifiableList(
        Arrays.asList("冷却时间", "固定射程"));
    public static List<SetInfo> sets() { return SETS; }
    public static SetInfo byName(String name) {
        if (name == null) return null;
        for (SetInfo s: SETS) if (s.zh.equals(name) || s.en.equalsIgnoreCase(name)) return s;
        return null;
    }
    public static SetInfo detect(String text) {
        if (text == null) return null;
        String t=text.toLowerCase(Locale.ROOT).replace(" ", "").replace("_", "").replace("-", "");
        SetInfo found=null;
        for (SetInfo s: SETS) {
            String[] names=(s.zh+"|"+s.en+"|"+s.aliases).toLowerCase(Locale.ROOT).split("\\|");
            for (String n:names) {
                String key=n.replace(" ", "").replace("_", "").replace("-", "");
                if (!key.isEmpty() && t.contains(key)) {
                    if (found != null && found != s) return null;
                    found=s;
                }
            }
        }
        return found;
    }
}

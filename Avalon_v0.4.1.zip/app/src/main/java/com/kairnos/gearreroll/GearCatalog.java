package com.kairnos.gearreroll;

import java.util.*;

/**
 * 全部可重掷套装目录（史诗 + 传奇）。
 *
 * 只有史诗/传奇装备可以被重掷，因此这里收录游戏中所有 Epic/Legendary 套装，
 * 共 28 套。中文名称以国际服中文界面实际显示为准，英文名与多个别名作为兜底，
 * 避免不同版本译文差异导致识别失败。
 */
public final class GearCatalog {
    private GearCatalog() {}

    public static final class SetInfo {
        public final String zh;       // 游戏内中文名（主）
        public final String en;       // 英文名（稳定键）
        public final String rarity;   // 传奇 / 史诗
        public final String aliases;  // 其他可能的中文/英文写法
        public final String bonus;    // 套装效果说明（界面展示用）
        public SetInfo(String zh, String en, String rarity, String aliases, String bonus) {
            this.zh = zh; this.en = en; this.rarity = rarity; this.aliases = aliases; this.bonus = bonus;
        }
        public String searchable() { return (zh + "|" + en + "|" + aliases).toLowerCase(Locale.ROOT); }
        public String label() { return zh + " · " + en + "  〔" + rarity + "〕"; }
    }

    private static final List<SetInfo> SETS = Collections.unmodifiableList(Arrays.asList(
        // ---------- 史诗（紫装） ----------
        new SetInfo("厨师", "Chef", "史诗", "厨子|大厨|Chef", "在场时全队主伤害+7%"),
        new SetInfo("少年", "Teenager", "史诗", "青少年|年轻人|Teen|Teenager", "主伤害+10%"),
        new SetInfo("建筑工", "Builder", "史诗", "建筑|建造者|Builder", "25%概率完全免伤"),
        new SetInfo("战术", "Tactical", "史诗", "战术装备|Tactical", "无视敌人50%子弹抗性"),
        new SetInfo("游侠", "Ranger", "史诗", "森林游侠|巡林客|游骑兵|Ranger", "暴击伤害+20%"),
        new SetInfo("快餐", "Fast Food", "史诗", "速食|FastFood|Fast Food", "生命值+25%"),
        // ---------- 传奇（金装） ----------
        new SetInfo("军用", "Military", "传奇", "军队|军事|军人|Military", "30%概率一次射击发射双倍子弹"),
        new SetInfo("猎人", "Hunter", "传奇", "猎手|Hunter", "与目标距离越远主伤害越高"),
        new SetInfo("绅士", "Gentleman", "传奇", "绅士套装|Gentleman", "暴击后2秒内主伤害+50%"),
        new SetInfo("外科", "Surgery", "传奇", "外科医生|手术|Surgeon|Surgery", "生命低于50%时主伤害翻倍"),
        new SetInfo("健身", "Fitness", "传奇", "健身者|健美|Fitness", "进攻性提升至100"),
        new SetInfo("瑞士制造", "SwissMade", "传奇", "瑞士|瑞士制|Swiss Made|SwissMade", "主伤害+17%"),
        new SetInfo("首领", "Boss", "传奇", "老大|领袖|Boss", "入场时全队主伤害+25%持续3秒"),
        new SetInfo("杀手", "Hitman", "传奇", "刺客|职业杀手|Hitman", "生命不满时暴击伤害+30%"),
        new SetInfo("赌徒", "Gambling", "传奇", "赌博|赌棍|Gambler|Gambling", "受伤后暴击几率+25%"),
        new SetInfo("消防员", "Firefighter", "传奇", "消防|Firefighter", "对燃烧目标伤害+30%"),
        new SetInfo("幸运儿", "Lucky Guy", "传奇", "幸运|LuckyGuy|Lucky Guy", "首次致命伤害保留1点生命"),
        new SetInfo("童子军", "Scout", "传奇", "侦察兵|侦查员|Scout", "击杀后获得20%生命护盾3秒"),
        new SetInfo("大男孩", "Big Boy", "传奇", "巨人|BigBoy|Big Boy", "每1000生命值伤害+5%"),
        new SetInfo("爱国者", "Patriot", "传奇", "爱国|Patriot", "队友阵亡时主伤害+7%"),
        new SetInfo("破冰者", "Ice Breaker", "传奇", "破冰装备|破冰|IceBreaker|Ice Breaker", "对眩晕/冰冻目标伤害+30%"),
        new SetInfo("独狼", "Lone Wolf", "传奇", "孤狼|LoneWolf|Lone Wolf", "主伤害+55%，场上每多一单位-20%"),
        new SetInfo("齿轮列车", "Gear Train", "传奇", "齿轮系|齿轮|GearTrain|Gear Train", "连续射击远程伤害递增至+100%"),
        new SetInfo("针垫", "Pincushion", "传奇", "针垫|Pincushion", "每次受击伤害+5%"),
        new SetInfo("碳纤维", "Carbon", "传奇", "碳|Carbon", "首次免60%伤害，第二次免40%"),
        new SetInfo("穿刺", "Piercing", "传奇", "穿透|尖刺|Piercing", "子弹穿透首个目标，对后续目标30%伤害"),
        new SetInfo("创伤包", "Trauma Kit", "传奇", "创伤|急救包|TraumaKit|Trauma Kit", "对流血目标伤害+35%"),
        new SetInfo("遗物", "Relics", "传奇", "遗物|Relic|Relics", "每350魅力为最前排队友+5%伤害")
    ));

    /** 界面中展示的 14 个当前游戏副词条类别。 */
    public static final List<String> STATS = Collections.unmodifiableList(Arrays.asList(
        "固定生命值", "固定近战伤害", "固定远程伤害", "生命值百分比", "近战伤害百分比",
        "远程伤害百分比", "暴击几率", "暴击伤害", "准备时间降低", "敏捷度",
        "魅力", "勇气", "射程百分比", "费用降低"
    ));

    /** 旧手册用词，仅用于兼容识别，不在界面中展示。 */
    public static final List<String> COMPATIBILITY_STATS = Collections.unmodifiableList(
        Arrays.asList("冷却时间", "固定射程"));

    /** 四个装备部位对应的主词条。 */
    public static final class Slot {
        public final String name;
        public final List<String> mains;
        Slot(String n, List<String> m) { name = n; mains = m; }
    }
    public static final List<Slot> SLOTS = Collections.unmodifiableList(Arrays.asList(
        new Slot("杯子", Arrays.asList("固定生命值")),
        new Slot("刀", Arrays.asList("固定远程伤害", "固定近战伤害")),
        new Slot("表", Arrays.asList("敏捷度", "准备时间降低")),
        new Slot("书", Arrays.asList("暴击几率", "暴击伤害", "生命值百分比", "远程伤害百分比", "近战伤害百分比"))
    ));

    public static List<SetInfo> sets() { return SETS; }

    public static SetInfo byName(String name) {
        if (name == null) return null;
        String n = name.trim().toLowerCase(Locale.ROOT);
        for (SetInfo s : SETS) {
            if (s.zh.equals(name) || s.en.equalsIgnoreCase(n)) return s;
            for (String a : s.aliases.split("\\|")) if (a.equalsIgnoreCase(n)) return s;
        }
        return null;
    }

    /**
     * 从一段文字里探测套装。返回 null 表示未识别或存在歧义。
     * 优先匹配较长的键，避免短词误匹配。
     */
    public static SetInfo detect(String text) {
        if (text == null) return null;
        String t = text.toLowerCase(Locale.ROOT).replace(" ", "").replace("_", "").replace("-", "");
        SetInfo found = null;
        int bestLen = 0;
        for (SetInfo s : SETS) {
            for (String n : s.searchable().split("\\|")) {
                String key = n.replace(" ", "").replace("_", "").replace("-", "");
                if (key.isEmpty() || !t.contains(key)) continue;
                if (key.length() > bestLen) { bestLen = key.length(); found = s; }
                else if (key.length() == bestLen && found != s) { return null; }
            }
        }
        return found;
    }

    /** 该主词条是否属于该部位。 */
    public static boolean mainAllowedForSlot(String main, String slot) {
        for (Slot s : SLOTS) {
            if (!s.name.equals(slot)) continue;
            for (String m : s.mains) if (m.equals(main)) return true;
            return false;
        }
        return true;
    }
}

plugins { id("com.android.application") }

android {
    namespace = "com.kairnos.gearreroll"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kairnos.gearreroll"
        minSdk = 30
        targetSdk = 35
        versionCode = 4
        versionName = "0.3.1"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Bundled on-device Chinese OCR; the app does not upload screenshots.
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
    testImplementation("junit:junit:4.13.2")
}

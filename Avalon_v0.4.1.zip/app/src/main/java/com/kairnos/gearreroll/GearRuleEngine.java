package com.kairnos.gearreroll;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 保守的规则判定器。UNKNOWN 永远表示不点击。 */
public final class GearRuleEngine {
    private GearRuleEngine() {}

    public enum Decision { KEEP, REROLL, SKIP, UNKNOWN }

    public static final class Snapshot {
        public String set = "", rarity = "", part = "", main = "";
        public final List<String> subs = new ArrayList<>();
        public int level = -1;
        public boolean protectedItem = false, uncertain = false;
        public String raw = "";
    }

    public static final class Config {
        public final Set<String> wanted = new LinkedHashSet<>();
        public final Set<String> must = new LinkedHashSet<>();
        public final Set<String> allowedMain = new LinkedHashSet<>();
        public int minHits = 0;
        public boolean usePreset = true;
        public boolean enforceCost = true;   // 手册底线：核心池含“费用降低”的套装必须带成本
        public String part = "全部";
    }

    public static final class Result {
        public final Decision decision;
        public final String reason;
        public final int matched, expected;
        Result(Decision d, String r, int m, int e) { decision = d; reason = r; matched = m; expected = e; }
    }

    // ---------------------------------------------------------------
    // 词条名归一化：把 OCR 出来的各种写法映射到 14 个标准类别之一
    // ---------------------------------------------------------------
    public static String normalize(String raw) {
        if (raw == null) return "";
        String s = raw.toLowerCase(Locale.ROOT).replace(" ", "").replace("：", ":");
        // 去掉数值，保留百分号
        s = s.replaceAll("[+＋−\\-]?\\d+(?:[.,]\\d+)?", "");
        s = s.replace("％", "%").replace("百分之", "%");

        if (contains(s, "固定生命值") || (contains(s, "生命值", "生命", "hp", "health") && !contains(s, "%", "百分比", "percent"))) {
            return "固定生命值";
        }
        if (contains(s, "生命值百分比", "生命百分比", "生命值%", "生命%")) return "生命值百分比";
        if (contains(s, "近战伤害百分比", "近战百分比", "近战伤害%", "近战%")) return "近战伤害百分比";
        if (contains(s, "固定近战伤害", "近战伤害", "近战攻击伤害", "meleedmg", "meleedamage")) return "固定近战伤害";
        if (contains(s, "远程伤害百分比", "远程百分比", "远程伤害%", "远程%", "远伤%")) return "远程伤害百分比";
        if (contains(s, "固定远程伤害", "远程伤害", "射击伤害", "远程攻击伤害", "rangeddmg", "rangeddamage", "远伤")) return "固定远程伤害";
        if (contains(s, "暴击几率", "暴击率", "暴击机会", "暴击概率", "critchance")) return "暴击几率";
        if (contains(s, "暴击伤害", "爆伤", "暴击伤害加成", "critdamage", "critdmg")) return "暴击伤害";
        if (contains(s, "准备时间降低", "准备时间", "部署时间降低", "preptime", "preparationtime")) return "准备时间降低";
        if (contains(s, "冷却时间", "冷却", "cooldown")) return "冷却时间";
        if (contains(s, "敏捷度", "敏捷", "agility")) return "敏捷度";
        if (contains(s, "魅力", "charisma")) return "魅力";
        if (contains(s, "勇气", "valor")) return "勇气";
        if (contains(s, "费用降低", "成本降低", "费用", "成本", "cost")) return "费用降低";
        if (contains(s, "射程百分比", "射程%")) return "射程百分比";
        if (contains(s, "射程", "range")) return "固定射程";
        // 兜底：含 % 的生命/近战/远程已在上面处理，这里不再猜。
        return "";
    }

    private static boolean contains(String s, String... needles) {
        for (String n : needles) if (s.contains(n.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    public static int readLevel(String text) {
        if (text == null) return -1;
        Matcher m = Pattern.compile("(?:等级|级别|lv\\.?|level)\\s*[:：]?\\s*(\\d+)", Pattern.CASE_INSENSITIVE).matcher(text);
        if (m.find()) try { return Integer.parseInt(m.group(1)); } catch (Exception ignored) {}
        return -1;
    }

    public static Result evaluate(Snapshot s, Config c) {
        if (s == null || c == null) return unknown("缺少装备快照或配置");

        // 品质可以由套装目录推断
        if (s.rarity == null || s.rarity.isEmpty()) {
            GearCatalog.SetInfo info = GearCatalog.byName(s.set);
            if (info != null) s.rarity = info.rarity;
        }
        if (s.uncertain || s.level < 0 || s.set.isEmpty() || s.rarity.isEmpty() || s.main.isEmpty() || s.part.isEmpty())
            return unknown("装备身份、等级、品质、部位或主词条未完整识别");

        if (s.level != 1) return result(Decision.SKIP, "只允许重掷1级装备（当前等级" + s.level + "）", 0, 0);
        if (s.protectedItem) return result(Decision.SKIP, "检测到锁定/已装备标记", 0, 0);

        GearCatalog.SetInfo info = GearCatalog.byName(s.set);
        if (info == null) return unknown("套装不在目标清单中：" + s.set);
        // 目标品质与套装品质不符时跳过（例如把史诗当传奇刷）
        if (!info.rarity.equals(s.rarity)) return result(Decision.SKIP, "品质不符：该套装目标品质为" + info.rarity, 0, 0);

        int expected = GearOcrParser.expectedSubs(s.rarity);
        if (expected < 0) return unknown("未知品质：" + s.rarity);
        if (s.subs.size() != expected) return unknown("副词条数量异常：预期" + expected + "条，识别到" + s.subs.size() + "条");

        String main = normalize(s.main);
        if (main.isEmpty()) return unknown("主词条无法分类：" + s.main);

        if (!"全部".equals(c.part) && !c.part.equals(s.part)) return result(Decision.SKIP, "当前部位不是所选" + c.part, 0, expected);

        // 主副词条重复 / 副词条互相重复
        Set<String> seen = new HashSet<>();
        seen.add(main);
        Set<String> subSet = new LinkedHashSet<>();
        for (String raw : s.subs) {
            String key = normalize(raw);
            if (key.isEmpty()) return unknown("发现未识别副词条：" + raw);
            if (!seen.add(key)) return result(Decision.REROLL, "主副词条或副词条之间重复", 0, expected);
            subSet.add(key);
        }

        // 组装目标词条集合
        Set<String> wanted = new LinkedHashSet<>(), must = new LinkedHashSet<>();
        if (c.usePreset) applyPreset(s.set, wanted, must);
        wanted.addAll(c.wanted);
        must.addAll(c.must);
        wanted.addAll(must);
        if (wanted.isEmpty()) return unknown("尚未设置想要词条");

        // 必带词条
        if (!subSet.containsAll(must)) {
            Set<String> miss = new LinkedHashSet<>(must);
            miss.removeAll(subSet);
            return result(Decision.REROLL, "缺少必带词条：" + String.join("、", miss), countHits(subSet, wanted), expected);
        }

        // 主词条限制
        if (!c.allowedMain.isEmpty() && !c.allowedMain.contains(main))
            return result(Decision.REROLL, "主词条不在允许列表：" + main, countHits(subSet, wanted), expected);

        // 套装专属冲突（绅士近战/远程混用等）
        if (c.usePreset) {
            String presetReason = presetConflict(s, subSet, main);
            if (presetReason != null) return result(Decision.REROLL, presetReason, countHits(subSet, wanted), expected);
        }

        int hits = countHits(subSet, wanted);
        int min = c.minHits > 0 ? c.minHits : (s.rarity.equals("传奇") ? 3 : 3);
        if (min > expected) min = expected;
        if (hits < min) return result(Decision.REROLL, "命中不足：" + hits + "/" + min, hits, expected);

        return result(Decision.KEEP, "达标：命中" + hits + "条 / 副词条" + expected + "条", hits, expected);
    }

    private static int countHits(Set<String> got, Set<String> want) {
        int n = 0;
        for (String s : got) if (want.contains(s)) n++;
        return n;
    }

    private static Result unknown(String reason) { return result(Decision.UNKNOWN, reason, 0, 0); }
    private static Result result(Decision d, String s, int m, int e) { return new Result(d, s, m, e); }

    // ---------------------------------------------------------------
    // 五套手册预设（其余套装使用通用可编辑池）
    // ---------------------------------------------------------------
    private static void applyPreset(String set, Set<String> wanted, Set<String> must) {
        switch (set) {
            case "绅士":
                Collections.addAll(wanted, "费用降低", "暴击伤害", "固定近战伤害", "近战伤害百分比",
                        "固定远程伤害", "远程伤害百分比", "准备时间降低");
                must.add("费用降低");
                break;
            case "爱国者":
                Collections.addAll(wanted, "固定远程伤害", "远程伤害百分比", "暴击伤害", "暴击几率", "射程百分比");
                break;
            case "幸运儿":
                Collections.addAll(wanted, "生命值百分比", "固定生命值", "敏捷度", "费用降低", "准备时间降低");
                must.add("费用降低");
                break;
            case "童子军":
                Collections.addAll(wanted, "生命值百分比", "固定生命值", "固定近战伤害", "近战伤害百分比", "费用降低");
                must.add("费用降低");
                break;
            case "战术":
                Collections.addAll(wanted, "固定射程", "射程百分比", "固定远程伤害", "远程伤害百分比", "费用降低", "暴击伤害");
                must.add("费用降低");
                break;
            default:
                // 其余套装的“核心词条池”由用户在界面里自选；这里不伪造官方最佳词条。
                wanted.addAll(GearCatalog.STATS);
                break;
        }
    }

    private static String presetConflict(Snapshot s, Set<String> subs, String main) {
        if ("绅士".equals(s.set)) {
            boolean melee = subs.contains("固定近战伤害") || subs.contains("近战伤害百分比") || main.contains("近战");
            boolean ranged = subs.contains("固定远程伤害") || subs.contains("远程伤害百分比") || main.contains("远程");
            if (melee && ranged) return "绅士套装不能同时出现近战与远程词条";
        }
        return null;
    }
}

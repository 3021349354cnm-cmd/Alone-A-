package com.kairnos.gearreroll;

import android.graphics.Rect;
import com.google.mlkit.vision.text.Text;
import java.util.*;

/** Offline OCR adapter. It fails closed whenever the stat row structure is ambiguous. */
public final class GearOcrParser {
    private GearOcrParser() {}
    public static final class Parsed {
        public final GearRuleEngine.Snapshot snapshot;
        public final Map<String,Rect> labels;
        public final String fullText;
        public final List<String> lines;
        public final int recognizedStats;
        Parsed(GearRuleEngine.Snapshot s,Map<String,Rect> l,String t,List<String> rows,int n){
            snapshot=s;labels=l;fullText=t;lines=rows;recognizedStats=n;
        }
    }
    public static Parsed parse(Text text,String selectedSet,String selectedPart) {
        GearRuleEngine.Snapshot s=new GearRuleEngine.Snapshot();
        Map<String,Rect> labels=new LinkedHashMap<>(); List<String> lines=new ArrayList<>(); StringBuilder all=new StringBuilder();
        for(Text.TextBlock block:text.getTextBlocks()) for(Text.Line line:block.getLines()){
            String v=compact(line.getText()); if(v.isEmpty())continue;
            lines.add(v);all.append(v).append('\n');
            Rect box=line.getBoundingBox();if(box!=null)labels.put(v,new Rect(box));
        }
        String full=all.toString();s.raw=full;
        s.level=GearRuleEngine.readLevel(full);
        GearCatalog.SetInfo detected=GearCatalog.detect(full);
        s.set=detected==null?"":detected.zh;
        s.rarity=readRarity(full);
        s.protectedItem=hasAny(full,"已装备","装备中","已锁定","锁定","locked","equipped","★","☆","金星","已穿戴");
        s.part=readPart(lines,selectedPart);

        List<String> stats=new ArrayList<>();
        boolean explicitMain=false, inSub=false, mainNext=false;
        for(String row:lines){
            if(hasAny(row,"副词条","副属性","substats","secondary")){inSub=true;continue;}
            if(hasAny(row,"主词条","主属性","mainstat","primary")){
                explicitMain=true;inSub=false;
                String tail=afterHeader(row,"主词条","主属性","mainstat","primary");
                if(!tail.isEmpty()&&!GearRuleEngine.normalize(tail).isEmpty()){
                    if(s.main.isEmpty())s.main=tail;
                }else mainNext=true;
                continue;
            }
            String key=GearRuleEngine.normalize(row);
            if(key.isEmpty())continue;
            if(!explicitMain && s.main.isEmpty()){s.main=row;mainNext=false;}
            else if(mainNext && s.main.isEmpty()){s.main=row;mainNext=false;}
            else if(inSub || explicitMain || !s.main.isEmpty())stats.add(row);
        }
        // Some screen layouts do not render headings; first recognized property is main stat.
        if(s.main.isEmpty() && !stats.isEmpty()){s.main=stats.remove(0);}
        s.subs.addAll(stats);
        // If OCR produced a localized item slot from a clear label, prefer it; otherwise infer only unambiguous slots.
        if(s.part.isEmpty())s.part=inferPart(GearRuleEngine.normalize(s.main));
        if(s.part.isEmpty() && !"全部".equals(selectedPart))s.part=selectedPart;
        int expected=s.rarity.equals("传奇")?4:(s.rarity.equals("史诗")?3:-1);
        int count=1+s.subs.size();
        if(s.level<0 || s.rarity.isEmpty() || s.set.isEmpty() || s.main.isEmpty() || s.part.isEmpty() || expected<0 || s.subs.size()!=expected) s.uncertain=true;
        // Duplicate OCR labels or unexpected extra recognized stat lines are treated as ambiguity.
        if(new HashSet<>(s.subs).size()!=s.subs.size() || count!=expected+1)s.uncertain=true;
        return new Parsed(s,labels,full,lines,count);
    }
    private static String compact(String v){return v==null?"":v.replaceAll("\\s+","").replace('％','%').trim();}
    private static String readRarity(String t){
        boolean legendary=hasAny(t,"传奇","legendary");boolean epic=hasAny(t,"史诗","epic");
        if(legendary==epic)return "";return legendary?"传奇":"史诗";
    }
    private static String readPart(List<String> lines,String selected){
        for(String raw:lines){
            String s=raw.toLowerCase(Locale.ROOT).replace(" ","");
            if(s.equals("杯")||s.equals("杯子")||s.equals("cup")||s.startsWith("杯子：")||s.startsWith("cup:"))return "杯子";
            if(s.equals("刀")||s.equals("匕首")||s.equals("knife")||s.equals("jackknife"))return "刀";
            if(s.equals("表")||s.equals("手表")||s.equals("watch")||s.equals("watches")||s.equals("chessclock"))return "表";
            if(s.equals("书")||s.equals("书籍")||s.equals("book")||s.equals("books"))return "书";
        }
        return "";
    }
    private static String inferPart(String main){
        if(main.equals("固定生命值"))return "杯子";
        if(main.equals("固定近战伤害")||main.equals("固定远程伤害"))return "刀";
        if(main.equals("敏捷度")||main.equals("准备时间降低")||main.equals("冷却时间"))return "表";
        if(!main.isEmpty())return "书";
        return "";
    }
    private static String afterHeader(String row,String... headers){
        for(String h:headers){int i=row.toLowerCase(Locale.ROOT).indexOf(h.toLowerCase(Locale.ROOT));if(i>=0)return row.substring(i+h.length()).replaceAll("^[：:]","");}
        return "";
    }
    private static boolean hasAny(String t,String...words){String x=t.toLowerCase(Locale.ROOT);for(String w:words)if(x.contains(w.toLowerCase(Locale.ROOT)))return true;return false;}
}

package com.kairnos.gearreroll;

import android.app.*;
import android.content.*;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.*;
import android.view.animation.*;
import android.widget.*;

import java.util.*;

/** 控制器：选择套装 / 部位 / 词条（想要 + 必带），并启动无障碍自动重掷。 */
public class MainActivity extends Activity {
    private static final String PREF = "gear_settings";
    private SharedPreferences prefs;

    private Spinner appSpinner, partSpinner;
    private final List<String> appPackages = new ArrayList<>();
    private TextView statusText, permissionText, ruleSummary, bonusText;
    private CheckBox safeCheck, presetCheck;
    private SeekBar minHits;

    private final int ink = Color.rgb(29, 34, 42);
    private final int muted = Color.rgb(111, 119, 129);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREF, MODE_PRIVATE);
        build();
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(24), dp(18), dp(30));
        GradientDrawable backdrop = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{0xfff3f5f8, 0xffe8edf3, 0xfff7f4ef});
        page.setBackground(backdrop);
        scroll.addView(page);

        TextView brand = txt("DEAD AHEAD  /  AVALON", 10, muted, true);
        brand.setLetterSpacing(.17f);
        page.addView(brand);
        TextView title = txt("装备重掷", 30, ink, true);
        page.addView(title, lp(-2, -2));
        page.addView(txt("离线截图识别 · 词条判定 · 自动重掷", 13, muted, false));

        // ---- 运行状态 ----
        LinearLayout state = card();
        addCard(page, state, "运行状态", "识别与执行信息");
        statusText = txt(prefs.getString("status", "等待授权"), 14, ink, true);
        state.addView(statusText);
        permissionText = txt("无障碍服务：检查中", 11, muted, false);
        LinearLayout.LayoutParams q = lp(-1, -2);
        q.topMargin = dp(6);
        state.addView(permissionText, q);

        // ---- 筛选目标 ----
        LinearLayout target = card();
        addCard(page, target, "筛选目标", "共 " + GearCatalog.sets().size() + " 套可重掷套装（6 史诗 + 22 传奇）");
        label(target, "目标游戏");
        appSpinner = new Spinner(this);
        populateApps();
        target.addView(appSpinner, lp(-1, 46));

        label(target, "目标套装（按队列顺序刷，可多选）");
        Button setPicker = button("选择要刷的套装", false);
        target.addView(setPicker, lp(-1, 46));
        setPicker.setOnClickListener(v -> showSetDialog());

        bonusText = txt("", 11, muted, false);
        LinearLayout.LayoutParams bt = lp(-1, -2);
        bt.topMargin = dp(6);
        target.addView(bonusText, bt);

        label(target, "装备部位");
        partSpinner = new Spinner(this);
        String[] parts = {"全部", "杯子", "刀", "表", "书"};
        partSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, parts));
        partSpinner.setSelection(Arrays.asList(parts).indexOf(prefs.getString("gear_part", "全部")));
        target.addView(partSpinner, lp(-1, 46));

        // 套装队列在弹窗里配置，这里不再需要 Spinner 监听。

        // ---- 词条筛选 ----
        LinearLayout filters = card();
        addCard(page, filters, "词条筛选", "14 条副词条可分别设为“想要”或“必带”；必带没出现直接淘汰");
        presetCheck = new CheckBox(this);
        presetCheck.setText("启用手册预设规则（幸运儿 / 绅士 / 爱国者 / 童子军 / 战术）");
        presetCheck.setTextColor(ink);
        presetCheck.setTextSize(12);
        presetCheck.setChecked(prefs.getBoolean("use_presets", true));
        filters.addView(presetCheck);

        Button config = button("配置想要 / 必带词条", false);
        filters.addView(config, lp(-1, 46));
        config.setOnClickListener(v -> showStatDialog());

        label(filters, "至少命中几条想要词条");
        minHits = new SeekBar(this);
        minHits.setMax(4);
        minHits.setProgress(prefs.getInt("min_hits", 0));
        filters.addView(minHits, lp(-1, 35));
        filters.addView(txt("0 = 使用默认阈值（传奇 3/4，史诗 3/3）", 10, muted, false));

        label(filters, "主词条限制");
        Button mainRules = button("设置允许的主词条", false);
        filters.addView(mainRules, lp(-1, 44));
        mainRules.setOnClickListener(v -> showMainDialog());

        ruleSummary = txt("当前使用手册默认规则", 11, muted, false);
        LinearLayout.LayoutParams rs = lp(-1, -2);
        rs.topMargin = dp(7);
        filters.addView(ruleSummary, rs);

        // ---- 安全闸门 ----
        LinearLayout safety = card();
        addCard(page, safety, "安全闸门", "条件不满足时不会点击任何装备按钮");
        safeCheck = new CheckBox(this);
        safeCheck.setText("我已在库存中排除已装备 / 锁定 / 金星 / 非目标品质装备");
        safeCheck.setTextColor(ink);
        safeCheck.setTextSize(12);
        safeCheck.setChecked(prefs.getBoolean("inventory_safe_confirmed", false));
        safety.addView(safeCheck);
        TextView safeNote = txt(
                "只处理 1 级装备。传奇必须准确读到 4 条副词条，史诗必须准确读到 3 条。"
                        + "识别缺失、条数不对、套装或品质不明，全部自动暂停，绝不盲点。",
                11, muted, false);
        LinearLayout.LayoutParams sn = lp(-1, -2);
        sn.topMargin = dp(6);
        safety.addView(safeNote, sn);

        // ---- 操作 ----
        LinearLayout controls = card();
        addCard(page, controls, "自动控制", "游戏内会出现悬浮控制条，可随时暂停或停止");
        Button save = button("保存当前筛选设置", false);
        controls.addView(save, lp(-1, 44));
        save.setOnClickListener(v -> saveSelections());

        Button launch = button("打开游戏并进入校准", true);
        controls.addView(launch, lp(-1, 50));
        launch.setOnClickListener(v -> { saveSelections(); launchGame(true); });

        Button start = button("开始自动筛选", true);
        controls.addView(start, lp(-1, 50));
        start.setOnClickListener(v -> {
            saveSelections();
            if (!safeCheck.isChecked()) { toast("请先确认库存安全筛选"); return; }
            if (!calibrationComplete()) { toast("请先在游戏里完成九点校准"); return; }
            if (!accessibility()) { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); toast("先开启 Avalon 无障碍服务"); return; }
            prefs.edit().putBoolean("auto_enabled", true).putString("status", "自动筛选已启动").apply();
            refresh();
            launchGame(false);
        });

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button pause = button("暂停", false), stop = button("紧急停止", false);
        actions.addView(pause, new LinearLayout.LayoutParams(0, dp(46), 1));
        actions.addView(stop, new LinearLayout.LayoutParams(0, dp(46), 1));
        controls.addView(actions);
        pause.setOnClickListener(v -> toggle(false, "已暂停"));
        stop.setOnClickListener(v -> toggle(false, "已紧急停止"));

        TextView footer = txt("ON-DEVICE OCR  ·  NO CLOUD UPLOAD", 10, muted, true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams f = lp(-1, -2);
        f.topMargin = dp(22);
        page.addView(footer, f);

        setContentView(scroll);
        page.setAlpha(0f);
        page.setTranslationY(dp(12));
        page.animate().alpha(1f).translationY(0f).setDuration(380)
                .setInterpolator(new DecelerateInterpolator()).start();
    }


    private void populateApps() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> results = getPackageManager().queryIntentActivities(i, 0);
        List<String> labels = new ArrayList<>();
        appPackages.clear();
        for (ResolveInfo r : results) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            labels.add(r.loadLabel(getPackageManager()) + "  ·  " + pkg);
            appPackages.add(pkg);
        }
        appSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        int n = appPackages.indexOf(prefs.getString("target_package", "com.mobirate.DeadAheadTactics"));
        if (n >= 0) appSpinner.setSelection(n);
    }

    private void saveSelections() {
        List<String> queue = farmQueue();
        String set = queue.isEmpty() ? "幸运儿" : queue.get(0);
        String part = partSpinner.getSelectedItem() == null ? "全部" : partSpinner.getSelectedItem().toString();
        String pkg = appSpinner.getSelectedItemPosition() >= 0 && appSpinner.getSelectedItemPosition() < appPackages.size()
                ? appPackages.get(appSpinner.getSelectedItemPosition())
                : "com.mobirate.DeadAheadTactics";
        prefs.edit()
                .putString("farm_sets", String.join("|", queue))
                .putString("gear_set", set)
                .putString("gear_part", part)
                .putString("target_package", pkg)
                .putBoolean("use_presets", presetCheck.isChecked())
                .putInt("min_hits", minHits.getProgress())
                .putBoolean("inventory_safe_confirmed", safeCheck.isChecked())
                .apply();
        refresh();
        toast("筛选设置已保存");
    }

    private List<String> farmQueue() {
        List<String> out = new ArrayList<>();
        String raw = prefs.getString("farm_sets", "");
        if (raw != null && !raw.trim().isEmpty()) {
            for (String x : raw.split("\\|")) if (!x.trim().isEmpty()) out.add(x.trim());
        }
        if (out.isEmpty()) out.add(prefs.getString("gear_set", "幸运儿"));
        return out;
    }

    private void showSetDialog() {
        List<String> queue = farmQueue();
        List<GearCatalog.SetInfo> sets = GearCatalog.sets();
        String[] labels = new String[sets.size()];
        boolean[] checked = new boolean[sets.size()];
        for (int i = 0; i < sets.size(); i++) {
            labels[i] = sets.get(i).zh + " · " + sets.get(i).en + "  〔" + sets.get(i).rarity + "〕";
            checked[i] = queue.contains(sets.get(i).zh);
        }
        new AlertDialog.Builder(this)
                .setTitle("选择要刷的套装（按列表顺序依次刷）")
                .setMultiChoiceItems(labels, checked, (d, which, on) -> checked[which] = on)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (d, w) -> {
                    List<String> out = new ArrayList<>();
                    for (int i = 0; i < sets.size(); i++) if (checked[i]) out.add(sets.get(i).zh);
                    if (out.isEmpty()) { toast("至少选一套"); return; }
                    prefs.edit().putString("farm_sets", String.join("|", out))
                            .putString("gear_set", out.get(0))
                            .putInt("farm_index", 0).apply();
                    updateFarmSummary();
                    updateRuleSummary();
                })
                .show();
    }

    private void updateFarmSummary() {
        if (bonusText == null) return;
        List<String> q = farmQueue();
        StringBuilder sb = new StringBuilder("队列（" + q.size() + " 套）：");
        sb.append(String.join(" → ", q));
        GearCatalog.SetInfo first = GearCatalog.byName(q.get(0));
        if (first != null) sb.append("\n第一套效果：").append(first.bonus);
        bonusText.setText(sb.toString());
    }

    private void showStatDialog() {
        String oldW = prefs.getString("wanted_stats", ""), oldM = prefs.getString("must_stats", "");
        Set<String> w = GearSettings.split(oldW), m = GearSettings.split(oldM);

        ScrollView sc = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), dp(8), dp(16), dp(8));
        sc.addView(list);

        Map<String, CheckBox[]> boxes = new LinkedHashMap<>();
        for (String stat : GearCatalog.STATS) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView name = txt(stat, 13, ink, true);
            row.addView(name, new LinearLayout.LayoutParams(0, dp(44), 1));
            CheckBox want = new CheckBox(this);
            want.setText("想要");
            want.setTextSize(11);
            want.setChecked(w.contains(stat) || m.contains(stat));
            CheckBox must = new CheckBox(this);
            must.setText("必带");
            must.setTextSize(11);
            must.setChecked(m.contains(stat));
            row.addView(want);
            row.addView(must);
            list.addView(row);
            boxes.put(stat, new CheckBox[]{want, must});
            must.setOnCheckedChangeListener((b, c) -> { if (c) want.setChecked(true); });
            want.setOnCheckedChangeListener((b, c) -> { if (!c && must.isChecked()) must.setChecked(false); });
        }

        new AlertDialog.Builder(this)
                .setTitle("副词条规则")
                .setView(sc)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", (d, which) -> {
                    Set<String> nw = new LinkedHashSet<>(), nm = new LinkedHashSet<>();
                    for (Map.Entry<String, CheckBox[]> e : boxes.entrySet()) {
                        if (e.getValue()[0].isChecked()) nw.add(e.getKey());
                        if (e.getValue()[1].isChecked()) nm.add(e.getKey());
                    }
                    prefs.edit().putString("wanted_stats", GearSettings.join(nw))
                            .putString("must_stats", GearSettings.join(nm)).apply();
                    updateRuleSummary();
                })
                .show();
    }

    private void showMainDialog() {
        Set<String> old = GearSettings.split(prefs.getString("allowed_main", ""));
        String[] stats = GearCatalog.STATS.toArray(new String[0]);
        boolean[] checked = new boolean[stats.length];
        for (int i = 0; i < stats.length; i++) checked[i] = old.contains(stats[i]);
        new AlertDialog.Builder(this)
                .setTitle("允许的主词条（可多选，不选＝不限）")
                .setMultiChoiceItems(stats, checked, (d, which, on) -> checked[which] = on)
                .setNegativeButton("不限", (d, w) -> {
                    prefs.edit().putString("allowed_main", "").apply();
                    updateRuleSummary();
                })
                .setPositiveButton("保存", (d, w) -> {
                    Set<String> out = new LinkedHashSet<>();
                    for (int i = 0; i < stats.length; i++) if (checked[i]) out.add(stats[i]);
                    prefs.edit().putString("allowed_main", GearSettings.join(out)).apply();
                    updateRuleSummary();
                })
                .show();
    }

    private void launchGame(boolean calibrate) {
        if (!accessibility()) {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            toast("先开启 Avalon 无障碍服务，再返回启动游戏");
            return;
        }
        String pkg = prefs.getString("target_package", "com.mobirate.DeadAheadTactics");
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) { toast("无法打开目标游戏"); return; }
        if (calibrate) {
            prefs.edit().putString("status",
                    "已打开游戏。请打开第一件 1 级装备详情页，再点悬浮条“校准”，按 8 步依次点选").apply();
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    private void toggle(boolean enabled, String status) {
        prefs.edit().putBoolean("auto_enabled", enabled).putString("status", status).apply();
        refresh();
    }

    private boolean calibrationComplete() {
        for (int i = 0; i < 9; i++) if (!prefs.getBoolean("anchor_valid_" + i, false)) return false;
        return true;
    }

    private boolean accessibility() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled != null && enabled.toLowerCase(Locale.ROOT)
                .contains(new ComponentName(this, GearAutomationService.class).flattenToString().toLowerCase(Locale.ROOT));
    }

    private void refresh() {
        if (statusText != null) {
            statusText.setText(prefs.getString("status",
                    prefs.getBoolean("auto_enabled", false) ? "运行中" : "等待授权"));
        }
        if (permissionText != null) {
            permissionText.setText("无障碍服务：" + (accessibility() ? "已授权" : "未授权")
                    + "  ·  Android 11+" + "  ·  校准：" + (calibrationComplete() ? "已完成" : "未完成"));
        }
        updateRuleSummary();
        updateFarmSummary();
    }

    private void updateRuleSummary() {
        if (ruleSummary == null) return;
        Set<String> w = GearSettings.split(prefs.getString("wanted_stats", ""));
        Set<String> m = GearSettings.split(prefs.getString("must_stats", ""));
        Set<String> a = GearSettings.split(prefs.getString("allowed_main", ""));
        ruleSummary.setText("想要 " + w.size() + " 条 · 必带 " + m.size() + " 条 · 主词条 "
                + (a.isEmpty() ? "不限" : a.size() + " 项"));
    }

    // ---- 小工具 ----
    private void addCard(LinearLayout p, LinearLayout c, String title, String sub) {
        LinearLayout.LayoutParams q = lp(-1, -2);
        q.topMargin = dp(13);
        p.addView(c, q);
        c.addView(txt(title, 15, ink, true));
        TextView t = txt(sub, 11, muted, false);
        LinearLayout.LayoutParams z = lp(-1, -2);
        z.topMargin = dp(4);
        c.addView(t, z);
        View line = new View(this);
        line.setBackgroundColor(0x1d546579);
        LinearLayout.LayoutParams li = lp(-1, 1);
        li.topMargin = dp(11);
        li.bottomMargin = dp(9);
        c.addView(line, li);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(15), dp(14), dp(15), dp(15));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xcffbfcfe);
        g.setCornerRadius(dp(19));
        g.setStroke(dp(1), 0x55ffffff);
        c.setBackground(g);
        c.setElevation(dp(3));
        return c;
    }

    private void label(LinearLayout p, String s) {
        TextView t = txt(s, 11, muted, true);
        LinearLayout.LayoutParams q = lp(-1, -2);
        q.topMargin = dp(8);
        p.addView(t, q);
    }

    private TextView txt(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String s, boolean primary) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(primary ? Color.WHITE : ink);
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                primary ? new int[]{0xff323e4b, 0xff526171} : new int[]{0xdffeffff, 0xdde9edf2});
        d.setCornerRadius(dp(13));
        if (!primary) d.setStroke(dp(1), 0x557b8b9c);
        b.setBackground(d);
        b.setElevation(0);
        return b;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
    }

    private int dp(float x) { return (int) (x * getResources().getDisplayMetrics().density + .5f); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}

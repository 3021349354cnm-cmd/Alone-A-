package com.kairnos.gearreroll;

import android.graphics.Rect;
import com.google.mlkit.vision.text.Text;
import java.util.*;

/**
 * 离线 OCR 适配器。结构不清晰时一律 fail-closed（返回 uncertain）。
 *
 * 与旧版的关键差异：
 * 1. 品质（传奇/史诗）在游戏里是图标/底色，不是文字，因此不再要求 OCR 读到“传奇”，
 *    改为从套装目录推断。
 * 2. 兼容“平铺列表”布局：没有“主词条/副词条”标题时，第一条识别到的词条即主词条。
 * 3. 过滤掉“新统计 +3 或 +4”“该物品将被用于交换……”等非词条行。
 */
public final class GearOcrParser {
    private GearOcrParser() {}

    public static final class Parsed {
        public final GearRuleEngine.Snapshot snapshot;
        public final Map<String, Rect> labels;
        public final String fullText;
        public final List<String> lines;
        public final int recognizedStats;
        Parsed(GearRuleEngine.Snapshot s, Map<String, Rect> l, String t, List<String> rows, int n) {
            snapshot = s; labels = l; fullText = t; lines = rows; recognizedStats = n;
        }
    }

    public static Parsed parse(Text text, String selectedSet, String selectedPart) {
        GearRuleEngine.Snapshot s = new GearRuleEngine.Snapshot();
        Map<String, Rect> labels = new LinkedHashMap<>();
        List<String> lines = new ArrayList<>();
        StringBuilder all = new StringBuilder();

        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String v = compact(line.getText());
                if (v.isEmpty()) continue;
                lines.add(v);
                all.append(v).append('\n');
                Rect box = line.getBoundingBox();
                if (box != null) labels.put(v, new Rect(box));
            }
        }
        String full = all.toString();
        s.raw = full;

        s.level = GearRuleEngine.readLevel(full);

        GearCatalog.SetInfo detected = GearCatalog.detect(full);
        if (detected != null) {
            s.set = detected.zh;
            // 品质以目录为准：游戏中品质是图标，不是文字。
            s.rarity = detected.rarity;
        }

        // 少数界面会直接写出品质文字，此时以文字为准（优先级更高）。
        String textRarity = readRarity(full);
        if (!textRarity.isEmpty()) s.rarity = textRarity;

        // 星级/锁标记在多数情况下代表“收藏/已装备”，属于受保护装备。
        // 但在重掷结果弹窗里星标只是品质装饰，因此只在非结果页才判为受保护。
        boolean resultScreen = has(full, "重掷结果", "继续") && has(full, "返回", "重掷");
        if (!resultScreen) {
            s.protectedItem = hasAny(full, "已装备", "装备中", "已锁定", "锁定", "locked", "equipped", "金星", "已穿戴");
        }

        s.part = readPart(lines, selectedPart);

        // ---- 词条行收集：只取第一段连续的词条块 ----
        // 词条在界面上是连续排列的一段；取到第一个非词条行就停止，
        // 这样会自动跳过“套装：幸运儿”以及其后的套装效果说明文字。
        List<String> stats = new ArrayList<>();
        boolean started = false;
        for (String row : lines) {
            if (hasAny(row, "主词条", "主属性", "mainstat", "primary",
                    "副词条", "副属性", "substats", "secondary")) continue;
            boolean isStat = startsWithStat(row) && !isNoise(row)
                    && row.replace(" ", "").length() <= 16
                    && !GearRuleEngine.normalize(row).isEmpty();
            if (!isStat) {
                if (started) break;
                continue;
            }
            started = true;
            if (s.main.isEmpty()) s.main = row;
            else stats.add(row);
        }
        s.subs.addAll(stats);

        if (s.part.isEmpty()) s.part = inferPart(GearRuleEngine.normalize(s.main));
        if (s.part.isEmpty() && !"全部".equals(selectedPart)) s.part = selectedPart;

        // 若目录已确定套装而品质仍为空，补上。
        if (s.rarity.isEmpty() && !s.set.isEmpty()) {
            GearCatalog.SetInfo info = GearCatalog.byName(s.set);
            if (info != null) s.rarity = info.rarity;
        }

        int expected = expectedSubs(s.rarity);
        int count = 1 + s.subs.size();
        if (s.level < 0 || s.rarity.isEmpty() || s.set.isEmpty() || s.main.isEmpty()
                || s.part.isEmpty() || expected < 0 || s.subs.size() != expected) {
            s.uncertain = true;
        }
        if (new HashSet<>(s.subs).size() != s.subs.size() || count != expected + 1) s.uncertain = true;

        return new Parsed(s, labels, full, lines, count);
    }

    /**
     * 只抽取词条行（用于“词条区放大二次识别”）。
     * 返回顺序即屏幕从上到下的顺序：第 0 条是主词条，其余是副词条。
     */
    public static List<String> parseStatsOnly(Text text) {
        List<String> out = new ArrayList<>();
        if (text == null) return out;
        for (Text.TextBlock block : text.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String v = compact(line.getText());
                if (v.isEmpty() || isNoise(v)) continue;
                if (!startsWithStat(v)) continue;
                if (GearRuleEngine.normalize(v).isEmpty()) continue;
                out.add(v);
            }
        }
        return out;
    }

    /**
     * 词条行必须以词条名开头。
     * 这条规则同时挡掉两类误识别：
     *  - 套装效果说明（“首次受到致命伤害时保留1点生命值”）含“生命值”字样；
     *  - “新统计 +3 或 +4”这类非词条行。
     */
    private static final String[] STAT_PREFIXES = {
            "固定生命值", "生命值百分比", "生命值", "生命",
            "固定近战伤害", "近战伤害百分比", "近战伤害", "近战",
            "固定远程伤害", "远程伤害百分比", "远程伤害", "远程", "远伤",
            "暴击机会", "暴击几率", "暴击率", "暴击伤害", "爆伤",
            "准备时间", "冷却时间", "敏捷度", "敏捷", "魅力", "勇气",
            "射程百分比", "射程", "费用降低", "成本", "费用",
            "health", "melee", "ranged", "crit", "prep", "cooldown",
            "agility", "charisma", "valor", "range", "cost"
    };

    static boolean startsWithStat(String line) {
        if (line == null) return false;
        String t = line.replace(" ", "").replace("　", "");
        String lower = t.toLowerCase(Locale.ROOT);
        for (String p : STAT_PREFIXES) {
            if (t.startsWith(p)) return true;
            if (lower.startsWith(p)) return true;
        }
        return false;
    }

    public static int expectedSubs(String rarity) {
        if ("传奇".equals(rarity)) return 4;
        if ("史诗".equals(rarity)) return 3;
        return -1;
    }

    /** 明显不是词条的文字行。 */
    private static boolean isNoise(String row) {
        String t = row.replace(" ", "");
        if (t.isEmpty()) return true;
        if (t.contains("新统计") || t.contains("该物品") || t.contains("同一套装")
                || t.contains("稀有度") || t.contains("随机物品")) return true;
        if (t.length() > 18 && !containsStat(t)) return true;
        return false;
    }

    private static boolean containsStat(String t) {
        return !GearRuleEngine.normalize(t).isEmpty();
    }

    private static String compact(String v) {
        return v == null ? "" : v.replaceAll("\\s+", "").replace('％', '%').trim();
    }

    private static String readRarity(String t) {
        boolean legendary = hasAny(t, "传奇", "legendary");
        boolean epic = hasAny(t, "史诗", "epic");
        if (legendary == epic) return "";
        return legendary ? "传奇" : "史诗";
    }

    private static String readPart(List<String> lines, String selected) {
        for (String raw : lines) {
            String s = raw.toLowerCase(Locale.ROOT).replace(" ", "");
            if (s.equals("杯") || s.equals("杯子") || s.equals("cup")
                    || s.startsWith("杯子：") || s.startsWith("杯子:") || s.startsWith("cup:")) return "杯子";
            if (s.equals("刀") || s.equals("匕首") || s.equals("knife") || s.equals("jackknife")) return "刀";
            if (s.equals("表") || s.equals("手表") || s.equals("watch")
                    || s.equals("watches") || s.equals("chessclock")) return "表";
            if (s.equals("书") || s.equals("书籍") || s.equals("book") || s.equals("books")) return "书";
        }
        return "";
    }

    private static String inferPart(String main) {
        if (main.equals("固定生命值")) return "杯子";
        if (main.equals("固定近战伤害") || main.equals("固定远程伤害")) return "刀";
        if (main.equals("敏捷度") || main.equals("准备时间降低") || main.equals("冷却时间")) return "表";
        if (!main.isEmpty()) return "书";
        return "";
    }

    private static boolean has(String t, String... words) {
        return hasAny(t, words);
    }

    private static boolean hasAny(String t, String... words) {
        if (t == null) return false;
        String x = t.toLowerCase(Locale.ROOT);
        for (String w : words) if (x.contains(w.toLowerCase(Locale.ROOT))) return true;
        return false;
    }
}

# Changelog

## 0.3.0

- Rebuilt the Android app around screenshot capture and on-device Chinese OCR.
- Replaced fixed screen coordinates with OCR bounding boxes and local green-control image detection.
- Added a 24-set target catalog: 22 Legendary sets plus Epic Builder and Tactical.
- Exposed exactly 14 current in-game substat categories in the configuration UI.
- Added per-stat Want / Must-have options, a minimum-hit threshold, and main-stat filters.
- Added manual presets for Lucky Guy, Gentleman, Patriot, Scout, and Tactical.
- Added strict level-1, rarity, substat-count, duplicate-stat, and ambiguity gates.
- Added an in-game floating control strip with Start, Pause, Stop, Calibrate, and Test.
- Applied the user-provided portrait thumbnail as the launcher icon.
- Added local rule-engine and OCR-parser fixture tests.

Build and real-game verification are still required on an Android device.


## 0.3.1
- 将 Android 桌面应用名称及无障碍服务名称统一为 Avalon。
- 保留用户提供的第三张头像作为应用启动图标（各密度图标资源已存在）。

## 0.3.2
- 修复编译错误：GearAutomationService.findGreenRerollIcon 里 cx/cy 重复定义。
- 应用图标换成新图（高清）。
- 包名改为 com.kairnos.avalon，固定签名，可直接覆盖升级。

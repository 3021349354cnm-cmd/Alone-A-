package com.kairnos.gearreroll;

import android.content.SharedPreferences;
import java.util.*;

public final class GearSettings {
    private GearSettings() {}
    public static GearRuleEngine.Config load(SharedPreferences p){
        GearRuleEngine.Config c=new GearRuleEngine.Config();
        c.part=p.getString("gear_part","全部");
        c.minHits=p.getInt("min_hits",0);
        c.usePreset=p.getBoolean("use_presets",true);
        c.wanted.addAll(split(p.getString("wanted_stats","")));
        c.must.addAll(split(p.getString("must_stats","")));
        c.allowedMain.addAll(split(p.getString("allowed_main","")));
        return c;
    }
    public static Set<String> split(String s){
        Set<String> out=new LinkedHashSet<>();if(s==null||s.trim().isEmpty())return out;
        for(String x:s.split("\\|"))if(!x.trim().isEmpty())out.add(x.trim());return out;
    }
    public static String join(Collection<String> c){return String.join("|",c);}
}

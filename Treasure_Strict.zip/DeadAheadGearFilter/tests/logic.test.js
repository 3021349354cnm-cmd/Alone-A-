const assert = require('assert');
const C = require('../core.js');
const CONFIG = require('../config.js');

assert.strictEqual(C.normalize(' 生命值 百分比 +7％ '), '生命值百分比7%');
assert.strictEqual(C.matchKeyword('生命值百分比 +7%', [
  '生命值', '生命值百分比'
], C.STAT_SYNONYMS), '生命值百分比');
assert.strictEqual(C.matchStatRow('生命值 7%', ['生命值', '生命值百分比'], C.STAT_SYNONYMS), '生命值百分比');
assert.strictEqual(C.matchStatRow('生命值 +150', ['生命值', '生命值百分比'], C.STAT_SYNONYMS), '生命值');
assert.strictEqual(C.matchStatRow('远程伤害 70', ['远程伤害', '远程伤害百分比'], C.STAT_SYNONYMS), '远程伤害');
assert.strictEqual(C.matchStatRow('远程伤害 +10%', ['远程伤害', '远程伤害百分比'], C.STAT_SYNONYMS), '远程伤害百分比');
assert.strictEqual(C.parseLevel('等級 12'), 12);
assert.strictEqual(C.parseLevel('等级1'), 1);
assert.strictEqual(C.parseLevel('等级3'), 3);
assert.strictEqual(C.parseLevel('没有等级文字'), null);

const mainStats = {
  '杯子': ['生命值'],
  '刀': ['近战伤害', '远程伤害'],
  '表': ['准备时间', '敏捷'],
  '书': ['暴击机会', '暴击伤害', '远程伤害百分比', '近战伤害百分比', '生命值百分比']
};
assert.strictEqual(C.inferPartFromMain('生命值', mainStats), '杯子');
assert.strictEqual(C.inferPartFromMain('远程伤害', mainStats), '刀');
assert.strictEqual(C.inferPartFromMain('敏捷', mainStats), '表');
assert.strictEqual(C.inferPartFromMain('暴击机会', mainStats), '书');

const cfg = {
  TARGET_CORE_AFFIX: '成本',
  REQUIRED_SUB_STATS: ['魅力'],
  REQUIRE_ALL_SUB_STATS: true
};
assert.strictEqual(C.evaluateAffixes({mainStat:'生命值',subStats:['成本','魅力']},cfg).ok, true);
assert.strictEqual(C.evaluateAffixes({mainStat:'成本',subStats:['魅力']},cfg).kind, 'conflict');
assert.strictEqual(C.evaluateAffixes({mainStat:'生命值',subStats:['魅力']},cfg).kind, 'junk');
assert.strictEqual(C.evaluateAffixes({mainStat:'生命值',subStats:['成本']},cfg).kind, 'junk');
assert.strictEqual(CONFIG.CORE_AFFIX_POOL.length, 14);
assert.strictEqual(CONFIG.SUB_STATS.length, 14);
assert.ok(CONFIG.CORE_AFFIX_POOL.includes(CONFIG.TARGET_CORE_AFFIX));
assert.ok(CONFIG.GOLD_SETS.includes('幸运儿'));
console.log('logic tests: OK');

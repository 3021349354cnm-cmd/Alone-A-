package com.kairnos.gearreroll;

import org.junit.Test;
import static org.junit.Assert.*;

public class GearRuleEngineTest {
    private GearRuleEngine.Snapshot lucky(String... subs) {
        GearRuleEngine.Snapshot s=new GearRuleEngine.Snapshot();s.set="幸运儿";s.rarity="传奇";s.part="杯子";s.main="固定生命值 +150";s.level=1;
        for(String x:subs)s.subs.add(x);return s;
    }
    @Test public void targetCatalogContainsExactlyTwentyFourSets(){assertEquals(24,GearCatalog.sets().size());}
    @Test public void configurationShowsExactlyFourteenCurrentSubstats(){assertEquals(14,GearCatalog.STATS.size());}
    @Test public void legendaryLuckyWithMandatoryCostAndThreeHitsIsKept(){
        GearRuleEngine.Result r=GearRuleEngine.evaluate(lucky("费用降低 -1","生命值 +5%","敏捷度 +5","准备时间降低 0.4"),new GearRuleEngine.Config());
        assertEquals(GearRuleEngine.Decision.KEEP,r.decision);
    }
    @Test public void missingMandatoryCostIsRejected(){
        GearRuleEngine.Result r=GearRuleEngine.evaluate(lucky("生命值 +5%","敏捷度 +5","准备时间降低 0.4","暴击伤害 +8%"),new GearRuleEngine.Config());
        assertEquals(GearRuleEngine.Decision.REROLL,r.decision);
    }
    @Test public void nonLevelOneItemIsSkipped(){GearRuleEngine.Snapshot s=lucky("费用降低 -1","生命值 +5%","敏捷度 +5","准备时间降低 0.4");s.level=12;assertEquals(GearRuleEngine.Decision.SKIP,GearRuleEngine.evaluate(s,new GearRuleEngine.Config()).decision);}
    @Test public void epicMustHaveExactlyThreeSubstats(){GearRuleEngine.Snapshot s=new GearRuleEngine.Snapshot();s.set="建筑";s.rarity="史诗";s.part="书";s.main="生命值 +5%";s.level=1;s.subs.add("固定生命值 +50");s.subs.add("敏捷度 +3");assertEquals(GearRuleEngine.Decision.UNKNOWN,GearRuleEngine.evaluate(s,new GearRuleEngine.Config()).decision);}
    @Test public void duplicateMainAndSubStatIsRejected(){GearRuleEngine.Snapshot s=lucky("费用降低 -1","固定生命值 +50","敏捷度 +5","准备时间降低 0.4");assertEquals(GearRuleEngine.Decision.REROLL,GearRuleEngine.evaluate(s,new GearRuleEngine.Config()).decision);}
}

# Changelog

## 0.3.0

- Rebuilt the Android app around screenshot capture and on-device Chinese OCR.
- Replaced fixed screen coordinates with OCR bounding boxes and local green-control image detection.
- Added a 24-set target catalog: 22 Legendary sets plus Epic Builder and Tactical.
- Exposed exactly 14 current in-game substat categories in the configuration UI.
- Added per-stat Want / Must-have options, a minimum-hit threshold, and main-stat filters.
- Added manual presets for Lucky Guy, Gentleman, Patriot, Scout, and Tactical.
- Added strict level-1, rarity, substat-count, duplicate-stat, and ambiguity gates.
- Added an in-game floating control strip with Start, Pause, Stop, Calibrate, and Test.
- Applied the user-provided portrait thumbnail as the launcher icon.
- Added local rule-engine and OCR-parser fixture tests.

Build and real-game verification are still required on an Android device.


## 0.3.1
- 将 Android 桌面应用名称及无障碍服务名称统一为 Avalon。
- 保留用户提供的第三张头像作为应用启动图标（各密度图标资源已存在）。

## 0.3.2
- 修复编译错误：GearAutomationService.findGreenRerollIcon 里 cx/cy 重复定义。
- 应用图标换成新图（高清）。
- 包名改为 com.kairnos.avalon，固定签名，可直接覆盖升级。

## 0.4.0
- 关键修复：品质（传奇/史诗）改为从套装目录推断。游戏里品质是图标不是文字，旧版要求 OCR 读到“传奇”二字，读不到就暂停，这是上一版用不了的根本原因。
- 按钮（重掷/继续/返回/绿色图标）改为“OCR 优先 + 八点校准坐标兜底”，不再依赖识别按钮小字。
- 词条识别增加“裁剪词条区 + 放大 3 倍 + 二次 OCR”，提升小字识别率。
- 弹窗类型改用长文本判断（确认框：该物品将被用于交换；结果框：新统计 / 重掷结果），比按钮小字可靠。
- 套装目录扩充到 28 套可重掷套装（6 史诗 + 22 传奇），中文名以国际服实际显示为准，英文名与多别名兜底。
- 校准点由 4 个扩展为 8 个（4 个文字区域 + 4 个按钮位置）。
- 主界面补充套装效果说明、校准状态显示，修正默认套装索引。
- 更新单元测试：28 套目录、别名识别、品质推断。

## 0.4.1
- 新增「自动切换套装」：在库存页自动点开底部套装筛选按钮 → 在列表里下滑找目标套装名 → 点击切换，不再需要人工选套装。
- 新增「套装队列」：主界面可多选要刷的套装，按列表顺序依次刷；一套刷完（连续 3 帧找不到 1 级装备）自动切下一套，队列走完停止。
- 校准点由 8 个扩展为 9 个，新增「套装筛选按钮」位置。
- 筛选识别加防抖：只有明确读到“另一个套装名”或“全部套装”才触发切换，读到非套装名一律按正确处理，避免来回抖动。
- 安全兜底不变：即使筛选没对准，详情页仍会校验套装必须匹配，不会重掷别的套装。
